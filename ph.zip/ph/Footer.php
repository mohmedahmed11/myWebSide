
<footer class="page-footer">
<div class="row">
    <div class="container">
        <!-- <div class="footer-links large-7 small-5 columns first-column" style="width:50%;">
            <div class="panel no-border" style="padding-left:0;">
                <h6>من نحن</h6>
            </div>
        </div> -->
        <div class="footer-links col-md-6 col-sm-6 col-xs-12 float-right" >
            <div class="">
                <a class="link" href="#">من نحن</a>
                <a class="link" href="#">الاسئلة المتكررة</a>
                <a class="link" id="privacy" href="#">سياسة الخصوصية</a>
                <a class="link" href="#">تواصل معنا</a>
            </div>
        </div>
        

        
        <div class="footer-social col-md-3 col-sm-6 col-xs-12 float-left">
            <!-- <div class="panel" style="margin: 0;padding:  0;"> -->
                    
                <div class="socialicons">
                    <a class="icon" href="LINK" title="Follow with Twitter" target="_blank"><i class="fa fa-twitter fa-2x"></i></a>
                    <a class="icon" href="LINK" title="Follow with Facebook" target="_blank"><i class="fa fa-facebook fa-2x"></i></a>
                    <a class="icon" href="LINK" title="Follow with Instagram" target="_blank"><i class="fa fa-instagram fa-2x"></i></a>
                    <a class="icon" href="LINK" title="Follow with YouTube" target="_blank"><i class="fa fa-youtube fa-2x"></i></a>
                </div>
                
                <p class="footer-brand-name"> بنان للتأمين &copy; 2018</p>
            <!-- </div> -->
        </div>
    </div>
</div>
</footer>





          <!-- The Modal -->
<div id="privacy_statement" class="privacy_statement hide">

<!-- Modal content -->


</div>


<div class="modal" style="color:#333;  text-align:center;    background-color: rgba(0, 0, 0, .5);" id="modal-privacy"  role="dialog">
  <div class="modal-dialog" style="margin: 10% auto;" role="document">
    <div class="modal-content">
      <div class="modal-header" >
        <h5 class="modal-title">سياسة الخصوصية</h5>
        <button type="button" class="close-me mode-close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="color:#555;">
      <div class="privacy_statement-content">
        سياسة خصوصية 

        عند استخدام خدماتنا، فإنك تأتمننا على معلوماتك. نحن ندرك أن هذه مسؤولية كبيرة ونعمل بجدية لحماية معلوماتك ونمنحك التحكم فيها.

        تهدف سياسةُ الخصوصية هذه إلى مساعدتك على فهم ماهية المعلومات التي نجمعها وسبب جمعنا لها، وكذلك طريقة تحديث معلوماتك وتصديرها وحذفها.
        يسري بتاريخ 25 مايو 2018 | النُسخ المؤرشفة | تنزيل ملف 
        </div>
      </div>
      <!-- <div class="modal-footer" style="text-align:center;">
        <button type="button" class="btn btn-primary close-me">حفظ</button> || 
        <button type="button" class="btn btn-secondary close-me" data-dismiss="modal">إلغاء</button>
      </div> -->
    </div>
  </div>
</div>


<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/jquery-confirm.min.js"></script>

<script>
function display() {
    var slider = document.getElementById("carousel-inner");
    var video = document.getElementById("vid");

    if (video.style.display === "none") {
      slider.style.display = "none";
      video.style.display = "block";
      video.play(); 

    } else {
      video.style.display = "none";
      slider.style.display = "block";
      video.pause(); 


    }
}

$("#privacy").click(function(){
    $("#modal-privacy").show();
});

$(".close-me").click(function(){
    $("#modal-privacy").hide();
});

</script>
<script>
// Get the modal
var modal = document.getElementById('privacy_statement');

// Get the button that opens the modal
var btn = document.getElementById("privacy");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>


<script>
    $( function() {
    $( "#Bn_Aga_Oth_Ins_Start_Date" ).datepicker();
    $( "#Bn_Aga_Oth_Ins_End_Date" ).datepicker();
    $( "#Bn_Aga_Oth_Ins_Birthdate" ).datepicker();
    } );
</script>
</body>
</html>