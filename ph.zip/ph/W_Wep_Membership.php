<?php
session_start();

if(@$_SESSION['status']!=1){
	echo "<script>location.href='index.php';</script>";
}

?>
<!-- -->


<!DOCTYPE html >
<html lang="ar" class="no-js" dir="rtl">
    <head id="ctl00_Head1"><meta charset="UTF-8" /><meta http-equiv="X-UA-Compatible" content="IE=10;Chrome=1;FF=3;OtherUA=4" /><meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" /><meta name="GENERATOR" content="Microsoft SharePoint" /><meta http-equiv="Content-type" content="text/html; charset=utf-8" /><meta http-equiv="Expires" content="0" /><title>
	شركة غيوم الودق لتقنية المعلومات
</title><link rel="stylesheet" href="css/normalize.css" /><!--[if IE 9]>
<link id="CssIE9" rel="stylesheet" type="text/css" href="/Style%20Library/sec/CSS/ng/css/IE9.css"/>
<![endif]-->
<link rel="stylesheet" href="css/font-awesome.min.css" />

<link id="CssRegistration1" rel="stylesheet" type="text/css" href="css/corev15.css?rev=oPMYfaqFDshrXtF%2Bx2UjjA%3D%3D"/>
<link id="CssRegistration2" rel="stylesheet" type="text/css" href="css/foundation.min.css"/>
<link id="CssRegistration4" rel="stylesheet" type="text/css" href="css/foundation.SPResets.css"/>
<link id="CssRegistration5" rel="stylesheet" type="text/css" href="css/stylesAr.css"/>
<link id="CssRegistration7" rel="stylesheet" type="text/css" href="css/SearchBoxStyle.css"/>

            
            
            <link rel="canonical" href="" />
            
            
        <link rel="icon" href="img/Logo_ar.png" type="image/x-icon" />
      <script  type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
              <!--[if lt IE 9]>
		<script type="text/javascript" src="js/html5.js">//<![CDATA[//]]></script>
		<link rel="stylesheet" href="../../_catalogs/masterpage/sec/css/ie.css" type="text/css" media="screen" />
	    <![endif]-->
		<style type="text/css">
			div#s4-ribbonrow {
			display:none;
			}
			div#suiteBar{
			display:none;
			}
		</style>
		
		  <script type="text/javascript">
   function getChronicDiseases(obj){
	   var selectBox = obj;
	   var selected = selectBox.options[selectBox.selectedIndex].value;
	   var textarea = document.getElementById("lsHaveChronicDiseases");
	   if(selected === '1'){
		   $("#ChronicDiseases").show(); 
		   $("#ChronicDiseases2").show();
	   }else{
		   $("#ChronicDiseases").hide();
		   $("#ChronicDiseases2").hide();
	   }
   }
 </script>
	    </head>
    <body id="page1" onhashchange="if (typeof(_spBodyOnHashChange) != 'undefined') _spBodyOnHashChange();">
    	 <span id="DeltaSPWebPartManager">
            
        </span>
        
         
        <div id="imgPrefetch" style="display:none">
<img src="img/Logo_ar.png?rev=23" />
<img src="img/spcommon.png?rev=23" />
</div>





            <div id="ctl00_SPSecurityTrimmedControl1">
	<div id="TurnOnAccessibility" style="display: none" class="s4-notdlg noindex"><a id="linkTurnOnAcc" href="#" class="ms-accessible ms-acc-button" onclick="SetIsAccessibilityFeatureEnabled(true);UpdateAccessibilityUI();document.getElementById('linkTurnOffAcc').focus();return false;">تشغيل وضع قابل للوصول بشكل أفضل</a></div><div id="TurnOffAccessibility" style="display: none" class="s4-notdlg noindex"><a id="linkTurnOffAcc" href="#" class="ms-accessible ms-acc-button" onclick="SetIsAccessibilityFeatureEnabled(false);UpdateAccessibilityUI();document.getElementById('linkTurnOnAcc').focus();return false;">إيقاف تشغيل الوضع القابل للوصول بشكل أفضل</a></div>
</div>
            <div id="ms-designer-ribbon">
                <div>
	
	<div id="s4-ribbonrow" style="visibility:hidden;display:none"></div>

</div>



            </div>
              
             <span id="ctl00_SPSecurityTrimmedControl2"></span>

         <div id="fadeMenu">
                <div id="secmain" class="body-Arabic">

                    <!-- Header -->
                    <header class="ms-dialogHidden">

                        <div class="header-top row">
                        <div class="large-12 columns no-padding">
						 <!-- Logo -->
                            <div class="logo-icon large-5 columns">
                                <a href="W_Wep_Main_Menu.php" ><img  src="img/Logo_ar.png" alt="بنان للتأمين" /></a>
                            </div>
                            <!-- End Logo -->
							
                            <!-- Language Bar -->
                            <div class="language-bar-container columns large-7 text-left no-padding ">
                                <div class="language-bar">
								    <a href="W_Wep_Main_Menu.php"><i class="fa fa-home"></i></a>
                                    | <span class="home-icon">
                                   <a href="#" id="ctl00_homepage">
                                        تسجيل عضوية</a></span>
										| <span class="home-icon">
                                   <a href="logout.php" id="ctl00_homepage">
                                        تسجيل خروج</a></span>
                                    | <span class="language-icon"><a  id="alang" style="font-weight:bold;text-decoration:none">En</a></span>
                                </div>
                            </div>
							<div class="header-navigation row">
                            <div class="columns">
                                <nav class="top-bar"  id="nav-menu">
                                    <section class="top-bar-section right">
                                        <div class="sticky-topbar"><a class="any-questions" href="#"></a></div>
                                        <ul>
                                            <li><a href="#">معلومات عن الشركة</a></li>
                                            <li class="divider"></li>
											<li><a href="#">التوظيف</a></li>
                                            <li class="divider"></li>
											<li><a href="#">عملائنا</a></li>
                                            <li class="divider"></li>
                                            <li><a href="#" class="last-item">للتواصل</a></li>
                                        </ul>
                                    </section>
                                </nav>
                            </div>
                        </div>
							
                            <!-- End Language Bar -->

            

                            <!-- Contact Us  
                            <div class="contact-us large-5 small-5 columns">
                    
                            </div>
                                                 <!-- End Contact Us -->

                            <!-- Search Box 

                            <div class="ms-tableCell ms-verticalAlignTop SearchBoxArabic" style="float: right; margin-top: 20px;">
                                    <div id="DeltaPlaceHolderSearchArea" class="ms-mpSearchBox ms-floatRight">
	
                                        
											<div id="searchInputBox">

                                                <div class="ms-webpart-chrome ms-webpart-chrome-fullWidth ">
		<div WebPartID="00000000-0000-0000-0000-000000000000" HasPers="true" id="WebPartWPQ1" width="100%" class="ms-WPBody " OnlyForMePart="true" allowDelete="false" style="" ><div componentid="ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr" id="ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr"><div id="SearchBox" name="Control"><div class="ms-srch-sb ms-srch-sb-border" id="ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr_sboxdiv"><input type="text" value="بحث..." maxlength="2048" accessKey="S" title="بحث..." id="ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr_sbox" autocomplete="off" autocorrect="off" onkeypress="EnsureScriptFunc('Search.ClientControls.js', 'Srch.U', function() {if (Srch.U.isEnterKey(String.fromCharCode(event.keyCode))) {$find('ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr').search($get('ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr_sbox').value);return Srch.U.cancelEvent(event);}})" onkeydown="EnsureScriptFunc('Search.ClientControls.js', 'Srch.U', function() {var ctl = $find('ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr');ctl.activateDefaultQuerySuggestionBehavior();})" onfocus="EnsureScriptFunc('Search.ClientControls.js', 'Srch.U', function() {var ctl = $find('ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr');ctl.hidePrompt();ctl.setBorder(true);})" onblur="EnsureScriptFunc('Search.ClientControls.js', 'Srch.U', function() {var ctl = $find('ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr'); if (ctl){ ctl.showPrompt(); ctl.setBorder(false);}})" class="ms-textSmall ms-srch-sb-prompt ms-helperText"/><a title="بحث" class="ms-srch-sb-searchLink" id="ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr_SearchLink" onclick="EnsureScriptFunc('Search.ClientControls.js', 'Srch.U', function() {$find('ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr').search($get('ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr_sbox').value);})" href="javascript: {}" ><img src="/_layouts/15/images/searchresultui.png?rev=23" class="ms-srch-sb-searchImg" id="searchImg" alt="بحث" /></a><div class="ms-qSuggest-container ms-shadow" id="AutoCompContainer"><div id="ctl00_ContentPlaceHolder1_SmallSearchInputBox1_csr_AutoCompList"></div></div></div></div></div><noscript><div id="ctl00_ContentPlaceHolder1_SmallSearchInputBox1_noscript">يبدو أن JavaScript غير مُمكن على المستعرض. الرجاء تشغيل JavaScript والمحاولة مرة أخرى.</div></noscript><div id="ctl00_ContentPlaceHolder1_SmallSearchInputBox1">

		</div><div class="ms-clear"></div></div>
	</div>

                                            </div>
                                        
                                    
</div>
                                </div>-->
                        </div>
						</div>
                        <!-- Menu Navigation -->
                         <div class="menu-navigation-container row">  
<div class="large-12 columns">
    <div class="menu-bar">
        <nav data-options="mobile_show_parent_link: true" class="top-bar">
            <section class="top-bar-section">
                <div class="menu-navigation ar" id="zz15_TopNavigationMenuV4">
                    <div class="menu horizontal menu-horizontal" id="secMenusContainer">
                        <ul id="navmain" class="root static">
                           
                        </ul>
                    </div>
                </div>
            </section>
        </nav>
    </div>
</div>
                
</div>
                        <!-- End Top Bar -->
                        
                    </header>
                    <!-- End Header -->

                    <!-- Main Image Slider -->
                    
<style type="text/css">
.menu-navigation-container, .breadcrumb-container{
	display:none !important;
}
.ms-webpartzone-cell{
	margin-bottom:auto;
}
#sidebar {
	width:50%;
	float:right;
	border:0!important;
	position:absolute;
	height:100%;
}
.slidebody{
right:50%;
position:relative;s
}
.quicklinksContainer div.blockhome.isOpen { transform: translate3d(260px, 0, 0); }
.hideDiv{
	display:none;
}
.imgWidth100 img {
	width:100%;
}
</style>








<link href="css/NewStylesAR.css" type="text/css" rel="stylesheet"/>
<link href="css/offcanvas.css" type="text/css" rel="stylesheet"/>

<div id="msidebar">
<div id="sidebar"></div>
</div>

<!--   -------------------------------------1) ----------------------------------------   -->



<!--   -----------------------------------------------------------------------------   -->


<!--   ---------------------------------------------2)--------------------------------   -->
<div class="row" style="margin:0px auto;">
	<div class="large-12 dvBodyColumns ">
		<a href="index.php">الرئيسية</a>&gt;
		<a href="W_Mob_Membership.php">تسجيل عضوية</a>
		
		<div class="boContent">
		<table class="viewbill">
		<tr>
		<td>رقم العضوية</td>
		<td><input type="text" name="" ></td>
		</tr>
		<tr>
		<td>رقم الهوية</td>
		<td><input type="text" name="" ></td>
		</tr>
		<tr>
		<td>الاسم</td>
		<td><input type="text" name="" size="50" ></td>
		</tr>
		<tr>
		<td>البريد الالكتروني</td>
		<td><input type="text" name="" size="50" ></td>
		</tr>
		<tr>
		<td>رقم الجوال</td>
		<td><input type="text" name="" ></td>
		</tr>
		<tr>
		<td>كلمة السر</td>
		<td><input type="password" name="" ></td>
		</tr>
		<tr>
		<td>اعادة كلمة السر</td>
		<td><input type="password" name="" ></td>
		</tr>
		<tr>
		<td><input type="submit" name="" value="التالي"></td>
		</tr>
		<table>
					</div>
	</div>
</div>
				            
				
			




<!--   ------------------------------------------ 3)------------------------------------     -->


		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   

                
             
	



<!--   ------------------------------------------------------------------------------     -->

<div class="mobile-footer-toggle">
	<div class="row apps text-center">

	</div>

</div>

                    <!-- End Image Slider -->

                    <div class="wrapper">
                        <!-- Content Container -->
                      

                        <!-- Footer -->
                       <div class="footer-container" >
                <footer class="row collapse">
				<div class="footer-links large-3 small-3 columns">
                        <div class="panel">
                            <ul class="no-bullet">
                                <li>
                                    <h6><a href="#">أحكام وشروط الاستخدام</a></h6>
                                </li>
                                <li>
                                    <h6><a href="#">أسئلة شائعة</a></h6>
                                </li>
                                <li>
                                    <h6><a href="#">خريطة الموقع</a></h6>
                                </li>
                                <li>
                                    <h6><a href="#">مواقعنا</a></h6>
                                </li>

                              
                            </ul>
                        </div>
                    </div>
                    <div class="footer-links large-3 small-5 columns first-column" style="width:30%;">
                        <div class="panel no-border" style="padding-left:0;">
                            <ul class="no-bullet">
                             <li><h6>للتواصل</h6></li>
                           <li ><i class="fa fa-phone-square"></i> (+966-xxxx-xxx) </li>
                           <li ><i class="fa fa-browser"></i> www.benanteam.com</li>
                           <li><a href="#" style="font-weight:normal;color:#666"><i class="fa fa-envelope-square"></i> info@benanteam.com</a></li> 
                            </ul>
                        </div>
                    </div>
                    <div class="footer-links large-3 small-4 columns" style="width:20%;">
                        <div class="panel">
                            
                            <ul class="no-bullet"><li>
                                <h6><a href="#">النشرة البريدية</a></h6>
                            </li>
							<li>
                                <input type="text" name="" preholder>
								<input type="submit" name="" value="ارسال" >
                            </li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="footer-social large-3 columns">
                        <div class="panel" style="margin-right:-20px">
                       		 
                            <div id="socialicons">
<a class="icon" href="LINK" title="Follow with Twitter" target="_blank"><i class="fa fa-twitter"></i></a>
<a class="icon" href="LINK" title="Follow with Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
<a class="icon" href="LINK" title="Follow with Instagram" target="_blank"><i class="fa fa-instagram"></i></a>
<a class="icon" href="LINK" title="Follow with YouTube" target="_blank"><i class="fa fa-youtube"></i></a>
</div>
                            <p class="mobfooter"> بنان للتأمين &copy; 2018</p>
                        </div>
                    </div>
                </footer>
        
            </div>
                        <!-- End Footer -->

         


                        <!-- Developer Dashboard -->
                        
                    </div>
                
</div></div>
            <div id="DeltaFormDigest">

        <span id="DeltaPlaceHolderUtilityContent">
            
        </span>
  
 

        
       </body>
           <!-- End Hide Unused Placeholders -->
</html><!-- تم التقديم باستخدام ملف تعريف ذاكرة تخزين مؤقتة:Public Internet (Purely Anonymous) في: 2018-07-20T11:03:17 -->