<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1.0">
  <title>index</title>
  <link rel="stylesheet" href="css/standardize.css">
  <link rel="stylesheet" href="css/index-grid.css">
  <link rel="stylesheet" href="css/index.css">
  <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

</head>
<body class="body page-index clearfix">
  <nav class="header clearfix">
    <div class="navlinks clearfix">

      <a class="enlang" href="#">English |</a>
	  
      <div class="container container-1 clearfix">

        <a class="home home-1" href="#"></a>
        <a class="home home-2" href="#"></a>
        <a class="home home-3" href="#"></a>
        <a class="home home-4" href="#"></a>
      </div>

      <div class="container container-2 clearfix">
      
        <input class="searchinput" placeholder="type here to search" type="search">
        <a class="search" type="submit" href="#"></a>
      </div>
    </div>
    <div class="logobrand"> </div>
	<div class="date">
	<p>
 
  <?php
		   include("libs/Calndar.php");
		   $hijri_settings=array('langcode'=>'ar','defaultformat'=>'_j _M _Yهـ','umalqura'=> TRUE,
		   'adj_data'=> array(1426 => 57250, 1429 => 57339,),
           'grdate_format' => 'j M Y',
 );  //settings of hijri date
		   $cal_obj=new Calendar($hijri_settings);
           $miladi =  date("Y/m/d");  
		   list($Y, $M, $D) = explode('/', $miladi); // return integer variables to month,day, and an year from miladi date
		   
		   $nameOfMonth_Miladi = $cal_obj->Jul_Month_Arabic_Name($M); //  miladi month name

		   
		   $dt = new DateTime();
           $jd = unixtojd( $dt->getTimestamp()); //getting julian date 
           $hijriDate=$cal_obj->JDToHijri($jd);
		   list($m, $d, $y) = explode('/', $hijriDate); // return integer variables to month,day, and an year from hijri
		   $nameOfMonth_hij = $cal_obj->month_name($m); //  hijri month name
		   $nameOfDay = date('D', strtotime($miladi)); //today english name
           $ar_day=$cal_obj->Day_Arabic_Name($nameOfDay); //today arabic name

			

	
	        echo($ar_day." ".$d." ".$nameOfMonth_hij." ".$y."هـ");	
			echo("</br>");	
			echo("الموافق ".$D." ".$nameOfMonth_Miladi." ".$Y."م"); ?>
</p>
</div>
  </nav>
  <a class="rateus" href="#">قم بتقييمنا</a>
  <div class="containerbody">
    <a class="healthinsurance" href="#" onclick="display();"></a>
    <a class="fullinsurance" href="#"></a>
    <a class="recentreports" href="#"></a>
    <a class="recentorders" href="#"></a>
    <a class="passengers" href="#"></a>
    <div class="slidercarousel"> 
        <div class="carousel-inner" id="carousel-inner">
            <div class="carousel-item active">
 </div>
            <div class="carousel-item active">
              <img class="d-block w-100" src="images/carproductbg.png" alt="Second slide">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="..." alt="Third slide">
            </div>
          </div>
<iframe class="vid" id="vid" src="https://www.youtube.com/watch?v=KHe6ZDH5mvY" frameborder="0" allowfullscreen></iframe>


    </div>
    <a class="othersinsurance" href="W_Wep_Ins_Against_Others_Insured_Data.php"></a>
    <a class="ourservices clearfix" href="#">
      <p class="text">خدماتنا</p>
    </a>
    <div class="login clearfix">
      <div class="labels">
        <div class="home"></div>
        <h3 class="account">الحساب الشخصي</h3>
      </div>
      <p class="links"><a>تسجيل دخول</a> | <a>تسجيل</a></p>
    </div>
  </div>
  <a class="appinstall" href="#"></a>
  <footer class="benanfotters">
<div></div>

    <p class="privacypolicy">بنان للتأمين © 2018</p>
  </footer>

  <script src="js/jquery-min.js"></script>
  <script>
function display() {
    var slider = document.getElementById("carousel-inner");
    var video = document.getElementById("vid");

    if (video.style.display === "none") {
      slider.style.display = "none";
      video.style.display = "block";
      video.play(); 

    } else {
      video.style.display = "none";
      slider.style.display = "block";
      video.pause(); 


    }
}
</script>
</body>
</html>