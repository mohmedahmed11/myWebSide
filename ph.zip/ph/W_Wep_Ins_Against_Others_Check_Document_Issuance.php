<?php
include_once("Header.php");

if(@$_SESSION['status']!=1){
	// echo "<script>location.href='index.php';</script>";
}

if(isset($_POST['Next'])){
	
	
	// echo "<script>location.href='W_Wep_Main_Menu.php;</script>";
	
	
}

?>
<!-- -->


<!--   -------------------------------------1) ----------------------------------------   -->



<!--   -----------------------------------------------------------------------------   -->

<div class="clearfix clearfix-space"></div>
<!--   ---------------------------------------------2)--------------------------------   -->

<div class="row" style="margin:0px auto;">
<div class="container">
 <!-- begin of the form 	 -->
 	<div class="panel panel-default">
	 	<div class="panel-heading"> <h4> تامين ضد الغير </h4> </div>

		<div class="panel-body">

			<!-- steps style -->
			<div class="row">
			<div class="container">

				<div class="against-other-steps">
					<a href="#"><img class="step" src="img/Step1.png"></a>
					<a href="#"><img class="step" src="img/Step2.png"></a>
					<a href="#"><img class="step" src="img/Step3.png"></a>
					<a href="#"><img class="step" src="img/Step4.png"></a>
					<a href="#"><img class="step" src="img/Step5.png"></a>
					<a href="#"><img class="step" src="img/Step6.png"></a>
					<a href="#"><img class="step" src="img/Step7.png"></a>
					<a href="#"><img class="step" src="img/Step8-a.png"></a>
				</div>
				</div>
			</div>


			<!-- end steps -->
			<div class="clearfix clearfix-space"></div>
			
			<div class="col-md-8 col-sm-12 col-xs-12 float-right">
		
		
			<form id="myForm" method="">
			<input type="hidden" name="Bn_Aga_Oth_Ins_Code" value="<?php //echo htmlentities($_GET['Bn_Aga_Oth_Ins_Code']);?>">
			<table class="table">

				<tr>
					<th colspan="2" class="text-center"><h3>إصدار الوثيقة</h3></th>
				</tr>
				<tr>
					<th colspan="2" class="text-center"><p>عزيزي......الرجاء ادخال رمز التحقق المرسل الى الجوال خلال 00:00</p></th>
				</tr>


				<tr>
					<td>رمز التحقق</td>
					<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-check"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_confirm" id="Bn_Aga_Oth_Ins_confirm" class="form-control" placeholder="رمز التحقق" aria-describedby="basic-addon1">
						</div>
					</td>
				</tr>
				</table>
				<table class="table text-right" >
					<tr>
						<input type="hidden" name="confirm-action" value="Bn_Aga_Oth_Finish_confirm">
						<th class="text-center"><a href="W_Wep_Ins_Against_Others_Payment_Data.php"><button type="button" id="back" class="btn btn-warning">   <- السابق  </button></a></th>
						<th class="text-center"><a href="#"><button type="button" id="finish" class="btn btn-info"> إنهاء </button></a></th>
					</tr>
				</table>


				
			</form>
				<br>
				<h5 style="color:#333;">عزيزي......سوف نقوم بارسال رسالة نصية برقم الفاتورة لجوالك بعد افادة البنك بالتسديد سوف نقوم بارسال الوثيقة العنوان المرفق</h5>
		
			</div>

			<div class="col-md-4 col-sm-hide col-xs-hide float-right">
				<div class="panel panel-warning">
					<div class="panel-heading"> إرشادات الموقع</div>
					<div class="panel-body">



					</div>
				</div>
			</div>


		</div> <!-- end of panel body  -->
		<!-- </div> -->
	</div>
 <!-- end of the form 	 -->
</div>
</div>




<!--   ------------------------------------------ 3)------------------------------------     -->

<?php include('Footer.php');?>
		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   



<!--   ------------------------------------------ 3)------------------------------------     -->

<script>

	$("#finish").click(function(){
		var check = 0;
			if($("#Bn_Aga_Oth_Ins_confirm").val() == ''){
				$("#Bn_Aga_Oth_Ins_confirm").addClass("alert-danger");
				check = 1;
			}

		if(check == 0){
			$("#myForm").submit();
		}else{
			$.alert({
				title: 'تنبيه!',
				content: 'عفوا يجب إدخال رمز التحقق أولاً !!',
			});
		}
	});

	$(document).on("submit", "#myForm", function()
	{
		// event.preventDefault();  
			
		var formData = new FormData(this);

        $.ajax({
            type:'POST',
            url: 'application/confirm.php',
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
				console.log(data);
				if(data == true){

					location.href='W_Wep_Main_Menu.php';

					console.log(data);
				}else{
					console.log(data);
				}
                
            },
            error: function(data){
                console.log(data);
            }
		});
		
       

		return false;
	});
	 
	 
 </script>   
		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   


                
             
	