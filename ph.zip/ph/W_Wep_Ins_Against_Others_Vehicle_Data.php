<?php include_once("Header.php"); ?>
<?php

// if(@$_SESSION['status']!=1){
// 	echo "<script>location.href='index.php';</script>";
// }

// if(isset($_POST['Next'])){
	
	
// 	$Bn_Aga_Oth_Ins_Code=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Code']);
// 	$Bn_Sup_Ins_Purpose_Code=mysql_real_escape_string($_POST['Bn_Sup_Ins_Purpose_Code']);
// 	$Bn_Sup_Vehicle_Use_Code=mysql_real_escape_string($_POST['Bn_Sup_Vehicle_Use_Code']);
// 	$Bn_Aga_Oth_Ins_HSCode=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_HSCode']);
// 	$Bn_Sup_Area_Code=mysql_real_escape_string($_POST['Bn_Sup_Area_Code']);
// 	$Bn_Sup_City_Code=mysql_real_escape_string($_POST['Bn_Sup_City_Code']);
// 	$Bn_Aga_Oth_Ins_Manufacturing_Year=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Manufacturing_Year']);
	
//       $bn_w_sql="UPDATE `bn_against_others_insurance_data` SET 
// 	 `Bn_Sup_Ins_Purpose_Code` = '$Bn_Sup_Ins_Purpose_Code', 
// 	 `Bn_Sup_Vehicle_Use_Code` = '$Bn_Sup_Vehicle_Use_Code', 
// 	 `Bn_Aga_Oth_Ins_HSCode` = '$Bn_Aga_Oth_Ins_HSCode', 
// 	 `Bn_Sup_Area_Code` = '$Bn_Sup_Area_Code', 
// 	 `Bn_Sup_City_Code` = '$Bn_Sup_City_Code', 
// 	 `Bn_Aga_Oth_Ins_Manufacturing_Year` = '$Bn_Aga_Oth_Ins_Manufacturing_Year'
// 	 WHERE `Bn_Aga_Oth_Ins_Code` = $Bn_Aga_Oth_Ins_Code";
// 		$bn_w_result=mysql_query($bn_w_sql);
		
// 	if($bn_w_result){
// 	echo "<script>location.href='W_Wep_Ins_Against_Others_Check_Data.php?Bn_Aga_Oth_Ins_Code=$Bn_Aga_Oth_Ins_Code';</script>";
// 	}
// 	else{
// 	//exit;	
// 	}
// }

?>
<!-- -->


<!--   -------------------------------------1) ----------------------------------------   -->



<!--   -----------------------------------------------------------------------------   -->


<div class="clearfix clearfix-space"></div>
<!--   ---------------------------------------------2)--------------------------------   -->

<div class="row" style="margin:0px auto;">
<div class="container">
 <!-- begin of the form 	 -->
 	<div class="panel panel-default">
	 	<div class="panel-heading"> <h4> تامين ضد الغير </h4> </div>

		<div class="panel-body">

			<!-- steps style -->
			<div class="row">
			<div class="container">

				<div class="against-other-steps">
					<a href="#"><img class="step" src="img/Step1.png"></a>
					<a href="#"><img class="step" src="img/Step2.png"></a>
					<a href="#"><img class="step" src="img/Step3-a.png"></a>
					<a href="#"><img class="step" src="img/Step4.png"></a>
					<a href="#"><img class="step" src="img/Step5.png"></a>
					<a href="#"><img class="step" src="img/Step6.png"></a>
					<a href="#"><img class="step" src="img/Step7.png"></a>
					<a href="#"><img class="step" src="img/Step8.png"></a>
				</div>
				</div>
			</div>


			<!-- end steps -->
			<div class="clearfix clearfix-space"></div>
			
			<div class="col-md-8 col-sm-12 col-xs-12 float-right">
			<form id="myForm" action="">

				<table class="table text-right" id="vehicle">
				<!-- <div class="vehicle-section hide"> -->
					<tr>
						<th colspan="2" class="text-center">بيانات المركبة</th>
					</tr>
					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-question"></i></span>
							<input type="text" class="form-control" name="Bn_Sup_Ins_Vehicle_Purpose" id="Bn_Sup_Ins_Vehicle_Purpose" placeholder="الغرض من التأمين" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-info"></i></span>
							<input type="text" class="form-control" name="Bn_Sup_Ins_Vehicle_HSCode" id="Bn_Sup_Ins_Vehicle_HSCode" placeholder="الرقم التسلسلي / الجمركي" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-cogs"></i></span>
							<input type="text" class="form-control" name="Bn_Sup_Ins_Vehicle_Use" id="Bn_Sup_Ins_Vehicle_Use" placeholder="الغرض من الإستخدام" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-map-marker"></i></span>
							<input type="text" class="form-control" name="Bn_Sup_Ins_Vehicle_Area_Code" id="Bn_Sup_Ins_Vehicle_Area_Code" placeholder="منطقة قيادة المركبة" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-map-pin"></i></span>
							<input type="text" class="form-control" name="Bn_Sup_Ins_Vehicle_City_Code" id="Bn_Sup_Ins_Vehicle_City_Code" placeholder="مدينة قيادة المركبة" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-calendar-plus-o"></i></span>
							<input type="text" class="form-control" name="Bn_Sup_Ins_Vehicle_Manufacturing_Year" id="Bn_Sup_Ins_Vehicle_Manufacturing_Year" placeholder="سنة الصنع" aria-describedby="basic-addon1">
						</div></td>
					</tr>
				</table>

				<table class="table text-right" >
					<tr>
						<input type="hidden" name="confirm-action" value="Bn_Aga_Oth_Veh_confirm">
						<th class="text-center"><a href="W_Wep_Ins_Against_Others_Driver_Data.php"><button type="button" id="back" class="btn btn-warning">   <- السابق  </button></a></th>
						<!-- <th class="text-center"><a href="W_Wep_Ins_Against_Others_Check_Data.php"><button type="button" id="next" class="btn btn-info">  التالي -> </button></a></th> -->
						<th class="text-center"><a href="#"><button type="button" id="next" class="btn btn-info">  التالي -> </button></a></th>
					</tr>
				</table>

			</form>
			</div>

			<div class="col-md-4 col-sm-hide col-xs-hide float-right">
				<div class="panel panel-warning">
					<div class="panel-heading"> إرشادات الموقع</div>
					<div class="panel-body">



					</div>
				</div>
			</div>


		</div> <!-- end of panel body  -->
		<!-- </div> -->
	</div>
 <!-- end of the form 	 -->
</div>
</div>




<!--   ------------------------------------------ 3)------------------------------------     -->

<?php include('Footer.php');?>
		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   

                
             
	


<!--   ------------------------------------------ 3)------------------------------------     -->

<script>

	$("#next").click(function(){

		var check = 0;
			if($("#Bn_Sup_Ins_Vehicle_Purpose").val() == ''){
				$("#Bn_Sup_Ins_Vehicle_Purpose").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Sup_Ins_Vehicle_HSCode").val() == ''){
				$("#Bn_Sup_Ins_Vehicle_HSCode").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Sup_Ins_Vehicle_Use").val() == ''){
				$("#Bn_Sup_Ins_Vehicle_Use").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Sup_Ins_Vehicle_Area_Code").val() == ''){
				$("#Bn_Sup_Ins_Vehicle_Area_Code").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Sup_Ins_Vehicle_City_Code").val() == ''){
				$("#Bn_Sup_Ins_Vehicle_City_Code").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Sup_Ins_Vehicle_Manufacturing_Year").val() == ''){
				$("#Bn_Sup_Ins_Vehicle_Manufacturing_Year").addClass("alert-danger");
				check = 1;
			}

		if(check == 0){
			$("#myForm").submit();

		}else{
			$.alert({
				title: 'تنبيه!',
				content: 'عفوا يجب ملئ جميع الحقول المطلوبة !!',
			});
		}
		
	});

	$(document).on("submit", "#myForm", function(event)
	{
		event.preventDefault();        


			//console.log(data);
		
			// alert("3");
			
		var formData = new FormData(this);

        $.ajax({
            type:'POST',
            url: 'application/confirm.php',
            data: formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
				
				if(data == true){

					location.href='W_Wep_Ins_Against_Others_Check_Data.php';
					console.log(data);
					
				}else{
					console.log(data);
				}
                
            },
            error: function(data){
                console.log(data);
            }
		});
		
		
       

		return false;
	});
	 
	 
 </script>   
		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   
