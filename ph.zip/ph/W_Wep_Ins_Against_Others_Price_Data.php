<?php
include_once("Header.php");

if(@$_SESSION['status']!=1){
	// echo "<script>location.href='index.php';</script>";
}


// if(isset($_POST['Next'])){
// 	$b=$_POST['b'];
// 	$Bn_Aga_Oth_Ins_Code=$_GET['Bn_Aga_Oth_Ins_Code'];
// 	echo "<script>location.href='W_Wep_Ins_Against_Others_Check_Document_Data.php?Bn_Aga_Oth_Ins_Code=$Bn_Aga_Oth_Ins_Code&b=$b';</script>";
// }

?>
<!-- -->


<!--   -------------------------------------1) ----------------------------------------   -->



<!--   -----------------------------------------------------------------------------   -->


<div class="clearfix clearfix-space"></div>
<!--   ---------------------------------------------2)--------------------------------   -->

<div class="row" style="margin:0px auto;">
<div class="container">
 <!-- begin of the form 	 -->
 	<div class="panel panel-default">
	 	<div class="panel-heading"> <h4> تامين ضد الغير </h4> </div>

		<div class="panel-body">

			<!-- steps style -->
			<div class="row">
			<div class="container">

				<div class="against-other-steps">
					<a href="#"><img class="step" src="img/Step1.png"></a>
					<a href="#"><img class="step" src="img/Step2.png"></a>
					<a href="#"><img class="step" src="img/Step3.png"></a>
					<a href="#"><img class="step" src="img/Step4.png"></a>
					<a href="#"><img class="step" src="img/Step5-a.png"></a>
					<a href="#"><img class="step" src="img/Step6.png"></a>
					<a href="#"><img class="step" src="img/Step7.png"></a>
					<a href="#"><img class="step" src="img/Step8.png"></a>
				</div>
				</div>
			</div>


			<!-- end steps -->
			<div class="clearfix clearfix-space"></div>
			
			<div class="col-md-8 col-sm-12 col-xs-12 float-right">

		
			<form id="myForm" action="">
			<!-- <input type="hidden" name="Bn_Aga_Oth_Ins_Code" value="<?php //echo $_GET['Bn_Aga_Oth_Ins_Code'];?>"> -->
			<table class="table">
		
				<tr>
					<th colspan="6" class="text-center"><h3>عرض الاسعار</h3></th>
				</tr>
				<tr>
				<td><img class="brand-image img" src="img/Logo_ar.png" ></td>
				<td>شيكان للتامين</td>
				<td>8</td>
				<td>2500 ريال</td>
				<td><a href="#" class="view-details">تفاصيل الوثيقة</a></td>
				<td><input type="radio" name="Bn_Aga_Oth_Ins_Code" class="Bn_Aga_Oth_Ins_Code" value="1"></td>
				</tr>
				<tr>
				<td><img class="brand-image img" src="img/Logo_ar.png" ></td>
				<td>الاسلامية للتامين</td>
				<td>15</td>
				<td>3850 ريال</td>
				<td><a href="#" class="view-details">تفاصيل الوثيقة</a></td>
				<td><input type="radio" name="Bn_Aga_Oth_Ins_Code" class="Bn_Aga_Oth_Ins_Code" value="2"></td>
				</tr>

				</table>
				<table class="table text-right" >
					<tr>
						<input type="hidden" name="confirm-action" value="Bn_Aga_Oth_Price_confirm">
						<th class="text-center"><a href="W_Wep_Ins_Against_Others_Check_Data.php"><button type="button" id="back" class="btn btn-warning">   <- السابق  </button></a></th>
						<!-- <th class="text-center"><a href="W_Wep_Ins_Against_Others_Check_Document_Data.php"><button type="button" id="next" class="btn btn-info">  التالي -> </button></a></th> -->
						<th class="text-center"><a href="#"><button type="button" id="next" class="btn btn-info">  التالي -> </button></a></th>
					</tr>
				</table>

			</form>
			</div>

			<div class="col-md-4 col-sm-hide col-xs-hide float-right">
				<div class="panel panel-warning">
					<div class="panel-heading"> إرشادات الموقع</div>
					<div class="panel-body">



					</div>
				</div>
			</div>


		</div> <!-- end of panel body  -->
		<!-- </div> -->
	</div>
 <!-- end of the form 	 -->
</div>
</div>




<!--   ------------------------------------------ 3)------------------------------------     -->

<?php include('Footer.php');?>
		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   


<!--   ------------------------------------------ 3)------------------------------------     -->

<script>

	$("#next").click(function(){

		if ($(".Bn_Aga_Oth_Ins_Code").is(':checked')) {

			$.confirm({
				title: 'تحقق!',
				content: 'هل انت متأكد من أنك مواقف علي شروط الوثيقة!',
				buttons: {
					confirm: function () {
						$("#myForm").submit();
					},
					cancel: function () {
						$.alert('Canceled!');
					}
				}
			});

			// $("#myForm").submit();
		}else{
			$.alert({
				title: 'تنبيه!',
				content: 'الرجاء إختيار واحدة من الخيارات المتاحة!!',
			});
		}

		//$("#myForm").submit();
		
	});

	$(document).on("submit", "#myForm", function(event)
	{
		event.preventDefault();        


			//console.log(data);
		
			// alert("3");
		

		//if(check == 0){
		var formData = new FormData(this);

        $.ajax({
            type:'POST',
            url: 'application/confirm.php',
            data: formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
				
				if(data == true){

					location.href='W_Wep_Ins_Against_Others_Check_Document_Data.php';
					console.log(data);
					
				}else{
					console.log(data);
				}
                
            },
            error: function(data){
                console.log(data);
            }
		});
		// }else{
			// $.alert({
				// 	title: 'تنبيه!',
				// 	content: 'عفوا يجب ملئ جميع الحقول المطلوبة !!',
				// });
		// }
		
       

		return false;
	});
	 
	 
 </script>   
		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   

                
             
	