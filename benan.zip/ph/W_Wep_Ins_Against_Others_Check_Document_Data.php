<?php
include_once("Header.php");

if(@$_SESSION['status']!=1){
	// echo "<script>location.href='index.php';</script>";
}
// 	genaral
	$Bn_Aga_Oth_Ins_Gov_No = '';
	$Bn_Aga_Oth_Ins_Gov_Id_No = '';
	$Bn_Aga_Oth_Ins_Gov_Id_Name = '';
	$Bn_Aga_Oth_Ins_Gov_Id_Date = '';
	$Bn_Aga_Oth_Ins_Gov_Id_Image = '';
	$Bn_Aga_Oth_Ins_Gov_Driver = '';

// 	spacial
	$Bn_Aga_Oth_Ins_Spe_No = '';
	$Bn_Aga_Oth_Ins_Spe_Id_No = '';
	$Bn_Aga_Oth_Ins_Spe_Id_Name = '';
	$Bn_Aga_Oth_Ins_Spe_Id_Date = '';
	$Bn_Aga_Oth_Ins_Spe_Id_Image = '';
	$Bn_Aga_Oth_Ins_Spe_Driver = '';

//	individuals	
	$Bn_Aga_Oth_Ins_Ind_no = '';
	$Bn_Aga_Oth_Ins_Ind_Birth_Date = '';
	$Bn_Aga_Oth_Ins_Ind_Work = '';
	$Bn_Aga_Oth_Ins_Ind_Job = '';
	$Bn_Aga_Oth_Ins_Ind_Work_Place = '';
	$Bn_Aga_Oth_Ins_Ind_National = '';
	$Bn_Aga_Oth_Ins_Ind_Gender = '';
	$Bn_Aga_Oth_Ins_Ind_Social = '';
	$Bn_Aga_Oth_Ins_Ind_Driver = '';

// 	driver data
	$Bn_Aga_Oth_Ins_Driver_Id_no = '';
	$Bn_Aga_Oth_Ins_Driver_Birthdate = '';
	$Bn_Aga_Oth_Ins_Driver_Work = '';
	$Bn_Aga_Oth_Ins_Driver_Job = '';
	$Bn_Aga_Oth_Ins_Driver_Work_Place = '';
	$Bn_Aga_Oth_Ins_Driver_National = '';
	$Bn_Aga_Oth_Ins_Driver_Gender = '';
	$Bn_Aga_Oth_Ins_Driver_Social = '';
	$Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has = '';
	$Bn_Aga_Oth_Ins_Driver_Health_Constraint = '';

// 	Vehicle data
	$Bn_Sup_Ins_Vehicle_Purpose = '';
	$Bn_Sup_Ins_Vehicle_HSCode = '';
	$Bn_Sup_Ins_Vehicle_Use = '';
	$Bn_Sup_Ins_Vehicle_Area_Code = '';
	$Bn_Sup_Ins_Vehicle_City_Code = '';
	$Bn_Sup_Ins_Vehicle_Manufacturing_Year = '';

//	public data
	$Bn_Sup_Sector_Code = '';
	$Bn_Sup_Sector_Name = '';
	$Bn_Aga_Oth_Ins_Start_Date = '';

	if (isset($_COOKIE['Bn_Aga_Oth_Ins'])) {
		# code...
		$Bn_Aga_Oth_Ins = json_decode($_COOKIE['Bn_Aga_Oth_Ins']);
		// dump($Bn_Aga_Oth_Ins->Bn_Sup_Sector_Code);
		$Bn_Sup_Sector_Code = $Bn_Aga_Oth_Ins->Bn_Sup_Sector_Code ;
		$Bn_Aga_Oth_Ins_Start_Date = $Bn_Aga_Oth_Ins->Bn_Aga_Oth_Ins_Start_Date ;

		if($Bn_Sup_Sector_Code == 'genaral'){
			$Bn_Sup_Sector_Name = 'حكومي';
		}else if($Bn_Sup_Sector_Code == 'spacial'){
			$Bn_Sup_Sector_Name = 'خاص';
		}else if($Bn_Sup_Sector_Code == 'individuals'){
			$Bn_Sup_Sector_Name = 'أفراد';
		}else if ($Bn_Sup_Sector_Code == 'diplomacy') {
			$Bn_Sup_Sector_Name = 'هيئات دبلوماسية';
		}else if ($Bn_Sup_Sector_Code == 'legalEntity') {
			$Bn_Sup_Sector_Name = 'جهة إعتبارية';
		}

		// $("#genaral").hide();
		// $("#spacial").hide();
		// $("#individuals").hide();

		if ($Bn_Sup_Sector_Code == 'genaral' || $Bn_Sup_Sector_Code == 'diplomacy' || $Bn_Sup_Sector_Code == 'legalEntity') {
			# code...
			$Bn_Aga_Oth_Ins_Gov = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Gov']);
			$Bn_Aga_Oth_Ins_Gov_No = $Bn_Aga_Oth_Ins_Gov->Bn_Aga_Oth_Ins_Gov_No;
			$Bn_Aga_Oth_Ins_Gov_Id_No = $Bn_Aga_Oth_Ins_Gov->Bn_Aga_Oth_Ins_Gov_Id_No;
			// $Bn_Aga_Oth_Ins_Gov_Id_Name = $Bn_Aga_Oth_Ins_Gov->Bn_Aga_Oth_Ins_Gov_Id_Name;
			$Bn_Aga_Oth_Ins_Gov_Id_Date = $Bn_Aga_Oth_Ins_Gov->Bn_Aga_Oth_Ins_Gov_Id_Date;
			$Bn_Aga_Oth_Ins_Gov_Id_Image = $Bn_Aga_Oth_Ins_Gov->Bn_Aga_Oth_Ins_Gov_Id_Image;
			$Bn_Aga_Oth_Ins_Gov_Driver = $Bn_Aga_Oth_Ins_Gov->Bn_Aga_Oth_Ins_Gov_Driver;
		}else if ($Bn_Sup_Sector_Code == 'spacial') {
			# code...
			$Bn_Aga_Oth_Ins_Spe = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Spe']);
			$Bn_Aga_Oth_Ins_Spe_No = $Bn_Aga_Oth_Ins_Spe->Bn_Aga_Oth_Ins_Spe_No;
			$Bn_Aga_Oth_Ins_Spe_Id_No = $Bn_Aga_Oth_Ins_Spe->Bn_Aga_Oth_Ins_Spe_Id_No;
			// $Bn_Aga_Oth_Ins_Spe_Id_Name = $Bn_Aga_Oth_Ins_Spe->Bn_Aga_Oth_Ins_Spe_Id_Name;
			$Bn_Aga_Oth_Ins_Spe_Id_Date = $Bn_Aga_Oth_Ins_Spe->Bn_Aga_Oth_Ins_Spe_Id_Date;
			$Bn_Aga_Oth_Ins_Spe_Id_Image = $Bn_Aga_Oth_Ins_Spe->$Bn_Aga_Oth_Ins_Spe_Id_Image;
			$Bn_Aga_Oth_Ins_Spe_Driver = $Bn_Aga_Oth_Ins_Spe->Bn_Aga_Oth_Ins_Spe_Driver;
		}else if ($Bn_Sup_Sector_Code == 'individuals'){
			# code...
			$Bn_Aga_Oth_Ins_Ind = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Ind']);
			$Bn_Aga_Oth_Ins_Ind_no = $Bn_Aga_Oth_Ins_Ind->Bn_Aga_Oth_Ins_Ind_no;
			$Bn_Aga_Oth_Ins_Ind_Birth_Date = $Bn_Aga_Oth_Ins_Ind->Bn_Aga_Oth_Ins_Ind_Birth_Date;
			$Bn_Aga_Oth_Ins_Ind_Work = $Bn_Aga_Oth_Ins_Ind->Bn_Aga_Oth_Ins_Ind_Work;
			$Bn_Aga_Oth_Ins_Ind_Edication = $Bn_Aga_Oth_Ins_Ind->Bn_Aga_Oth_Ins_Ind_Edication;
			$Bn_Aga_Oth_Ins_Ind_Work_Place = $Bn_Aga_Oth_Ins_Ind->Bn_Aga_Oth_Ins_Ind_Work_Place;
			$Bn_Aga_Oth_Ins_Ind_National = $Bn_Aga_Oth_Ins_Ind->Bn_Aga_Oth_Ins_Ind_National;
			$Bn_Aga_Oth_Ins_Ind_Gender = $Bn_Aga_Oth_Ins_Ind->Bn_Aga_Oth_Ins_Ind_Gender;
			$Bn_Aga_Oth_Ins_Ind_Social = $Bn_Aga_Oth_Ins_Ind->Bn_Aga_Oth_Ins_Ind_Social;
			$Bn_Aga_Oth_Ins_Ind_Driver = $Bn_Aga_Oth_Ins_Ind->Bn_Aga_Oth_Ins_Ind_Driver;
		}

		$show_driver_data = 0;
				
		if($Bn_Sup_Sector_Code == 'individuals' ) { 
			if($Bn_Aga_Oth_Ins_Ind_Driver == 1) {
				$show_driver_data = 1;
			}
		}else if ($Bn_Sup_Sector_Code == 'spacial') {
			if($Bn_Aga_Oth_Ins_Spe_Driver == 1) {
				$show_driver_data = 1;
			}
		}else if ($Bn_Sup_Sector_Code == 'genaral' || $Bn_Sup_Sector_Code == 'diplomacy' || $Bn_Sup_Sector_Code == 'legalEntity') {
			if($Bn_Aga_Oth_Ins_Gov_Driver == 1) {
				dump("dd");
				$show_driver_data = 1;
			}
		}
			
		if($show_driver_data == 1){	
			$Bn_Aga_Oth_Ins_Driver = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Driver']);
			$Bn_Aga_Oth_Ins_Driver_Id_no = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Id_no;
			$Bn_Aga_Oth_Ins_Driver_Birthdate = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Birthdate;
			$Bn_Aga_Oth_Ins_Driver_Work = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Work;
			$Bn_Aga_Oth_Ins_Driver_Edication = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Edication;
			$Bn_Aga_Oth_Ins_Driver_Work_Place = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Work_Place;
			$Bn_Aga_Oth_Ins_Driver_National = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_National;
			$Bn_Aga_Oth_Ins_Driver_Gender = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Gender;
			$Bn_Aga_Oth_Ins_Driver_Social = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Social;
			$Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has;
			$Bn_Aga_Oth_Ins_Driver_Health_Constraint = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Health_Constraint;
		}

		if(isset($_COOKIE['Bn_Aga_Oth_Ins_Vehicle'])){
			$Bn_Aga_Oth_Ins_Vehicle = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Vehicle']);
			$Bn_Sup_Ins_Vehicle_Purpose = $Bn_Aga_Oth_Ins_Vehicle->Bn_Sup_Ins_Vehicle_Purpose;
			$Bn_Sup_Ins_Vehicle_HSCode = $Bn_Aga_Oth_Ins_Vehicle->Bn_Sup_Ins_Vehicle_HSCode;
			$Bn_Sup_Ins_Vehicle_Use = $Bn_Aga_Oth_Ins_Vehicle->Bn_Sup_Ins_Vehicle_Use;
			$Bn_Sup_Ins_Vehicle_Area_Code = $Bn_Aga_Oth_Ins_Vehicle->Bn_Sup_Ins_Vehicle_Area_Code;
			$Bn_Sup_Ins_Vehicle_City_Code = $Bn_Aga_Oth_Ins_Vehicle->Bn_Sup_Ins_Vehicle_City_Code;
			$Bn_Sup_Ins_Vehicle_Manufacturing_Year = $Bn_Aga_Oth_Ins_Vehicle->Bn_Sup_Ins_Vehicle_Manufacturing_Year;
		}



	}else{
		echo("noooo");
	}



// if(!empty($_GET['Bn_Aga_Oth_Ins_Code'])){
// 	 $bn_w_sql_select="select * from `bn_against_others_insurance_data`
//                     left  join Bn_Sup_Sector on Bn_Sup_Sector.Bn_Sup_Sector_Code=bn_against_others_insurance_data.Bn_Sup_Sector_Code
// 					left  join Bn_Sup_Nationality on Bn_Sup_Nationality.Bn_Sup_Nationality_Code=bn_against_others_insurance_data.Bn_Sup_Nationality_Code
// 					left  join Bn_Sup_Gender on Bn_Sup_Gender.Bn_Sup_Gender_Code=bn_against_others_insurance_data.Bn_Sup_Gender_Code
// 					left  join Bn_Sup_Jobs on Bn_Sup_Jobs.Bn_Sup_Jobs_Code=bn_against_others_insurance_data.Bn_Sup_Jobs_Code
// 					left  join `Bn_Sup_Educational Qualification` on `Bn_Sup_Educational Qualification`.Bn_Sup_Edu_Qua_Code=bn_against_others_insurance_data.Bn_Sup_Edu_Qua_Code
// 					left  join Bn_Req_Insured_Health_Restrictions on Bn_Req_Insured_Health_Restrictions.Bn_Req_Insured_Hth_Res_No=bn_against_others_insurance_data.Bn_Req_Insured_Hth_Res_No
// 					left  join Bn_Sup_Insurance_Purpose on Bn_Sup_Insurance_Purpose.Bn_Sup_Ins_Purpose_Code=bn_against_others_insurance_data.Bn_Sup_Ins_Purpose_Code
// 					left  join Bn_Sup_Purpose_Of_Use on Bn_Sup_Purpose_Of_Use.Bn_Sup_Vehicle_Use_Code=bn_against_others_insurance_data.Bn_Sup_Vehicle_Use_Code
// 					left  join Bn_Sup_Area on Bn_Sup_Area.Bn_Sup_Area_Code=bn_against_others_insurance_data.Bn_Sup_Area_Code
// 					left  join Bn_Sup_City on Bn_Sup_City.Bn_Sup_City_Code=bn_against_others_insurance_data.Bn_Sup_City_Code
// 					WHERE `Bn_Aga_Oth_Ins_Code` =".htmlentities($_GET['Bn_Aga_Oth_Ins_Code']);
// 	// $bn_w_result_select=mysql_query($bn_w_sql_select);
// 	// $bn_w_row_select=mysql_fetch_assoc($bn_w_result_select);
// }


// if(isset($_POST['Next'])){
// 	$Bn_Aga_Oth_Ins_Code=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Code']);
// 	echo "<script>location.href='W_Wep_Ins_Against_Others_Price_Data.php?Bn_Aga_Oth_Ins_Code=$Bn_Aga_Oth_Ins_Code';</script>";
// }

?>
<!-- -->



<!--   -------------------------------------1) ----------------------------------------   -->



<!--   -----------------------------------------------------------------------------   -->


<div class="clearfix clearfix-space"></div>
<!--   ---------------------------------------------2)--------------------------------   -->

<div class="row" style="margin:0px auto;">
<div class="container">
 <!-- begin of the form 	 -->
 	<div class="panel panel-default">
	 	<div class="panel-heading"> <h4> تامين ضد الغير </h4> </div>

		<div class="panel-body">

			<!-- steps style -->
			<div class="row">
			<div class="container">

				<div class="against-other-steps">
					<a href="#"><img class="step" src="img/Step1.png"></a>
					<a href="#"><img class="step" src="img/Step2.png"></a>
					<a href="#"><img class="step" src="img/Step3.png"></a>
					<a href="#"><img class="step" src="img/Step4.png"></a>
					<a href="#"><img class="step" src="img/Step5.png"></a>
					<a href="#"><img class="step" src="img/Step6-a.png"></a>
					<a href="#"><img class="step" src="img/Step7.png"></a>
					<a href="#"><img class="step" src="img/Step8.png"></a>
				</div>
				</div>
			</div>


			<!-- end steps -->
			<div class="clearfix clearfix-space"></div>
			
			<div class="col-md-8 col-sm-12 col-xs-12 float-right">


			
			<table class="table" width="100%">

				<tr>
					<th colspan="4" class="text-center"><h3>بيانات الوثيقة</h3></th>
				</tr>
	
	
				<tr>
					<td>اسم الشركة</td>
					<td>شيكان للتامين</td>
					<td>مدة العرض</td>
					<td>8</td>
				</tr>
				<tr>
					<td>السعر</td>
					<td colspan="3">2500 ريال</td>
				</tr>

				<tr>
				<td colspan="4"><h3>بيانات المؤمن</h3></td>
				</tr>
				<tr>
				<td>تاريخ بداية الوثيقة</td>
				<td><?php echo $Bn_Aga_Oth_Ins_Start_Date; ?></td>
				<td>القطاع</td>
				<td><?php echo $Bn_Sup_Sector_Name; ?></td>
				</tr>
				<!-- <tr>
				<td>القطاع</td>
				<td colspan="3"><?php //echo $bn_w_row_select['Bn_Sup_Sector_Ar_Name']; ?></td>
				</tr> -->

				<!-- /////////////////////////////////////////////////////////////////////////////////-->
				<?php if($Bn_Sup_Sector_Code != 'individuals') { ?> 
				<tr>

				<?php if($Bn_Sup_Sector_Code == 'genaral' || $Bn_Sup_Sector_Code == 'diplomacy' || $Bn_Sup_Sector_Code == 'legalEntity') { ?> 

				<td >الرقم الحكومي</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Gov_No; ?></td>

				<?php }else if($Bn_Sup_Sector_Code == 'spacial') { ?>

				<td >الرقم التجاري</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Spe_No; ?></td>

				<?php } ?>
				<td></td>
				<td></td>
				
				</tr>

				<tr>
				<td >رقم التفويض</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Gov_Id_No.$Bn_Aga_Oth_Ins_Spe_Id_No; ?></td>
				<td >تاريخ التفويض</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Gov_Id_Date.$Bn_Aga_Oth_Ins_Spe_Id_Date; ?></td>
				</tr>

				<tr>
				<td >هل يوجد سائق</td>
				<td >
				<?php
				if($Bn_Aga_Oth_Ins_Gov_Driver == 1 || $Bn_Aga_Oth_Ins_Spe_Driver == 1){
					echo "نعم" ;
				}else if($Bn_Aga_Oth_Ins_Gov_Driver == 0 || $Bn_Aga_Oth_Ins_Spe_Driver == 0){
					echo "لا" ;
					}
				?>
				</td>
				<td >صورة التفويض</td>
				<td ><a href="#" link="<?php echo $Bn_Aga_Oth_Ins_Gov_Id_Image.$Bn_Aga_Oth_Ins_Spe_Id_Image; ?>">عرض صورة التفويض</a></td>
				</tr>

				<!-- /////////////////////////////////////////////////////////////////////////////////-->
				
				<?php }else if($Bn_Sup_Sector_Code == 'individuals') { ?>

				<tr>
				<td >رقم الهوية</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Ind_no; ?></td>
				<td >تاريخ الميلاد</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Ind_Birth_Date; ?></td>
				</tr>
				<tr>
				<td >المهنة</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Ind_Work; ?></td>
				<td >جهة العمل</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Ind_Work_Place; ?></td>
				</tr>
				<tr>
				<td >المؤهل التعليمي</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Ind_Edication; ?></td>
				<td >الجنسية</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Ind_National; ?></td>
				</tr>

				<tr>
				<td >الجنس</td>
				<td ><?php
				if($Bn_Aga_Oth_Ins_Ind_Gender == 1 ){
					echo "ذكر" ;
				}else if($Bn_Aga_Oth_Ins_Ind_Gender == 2 ){
					echo "أنثي" ;
					}
				?></td>
				<td >الحالة الإجتماعية</td>
				<td ><?php
				if($Bn_Aga_Oth_Ins_Ind_Social == 1 ){
					echo "متزوج/ة" ;
				}else if($Bn_Aga_Oth_Ins_Ind_Social == 2 ){
					echo "مطلق/ة" ;
					}
				?></td>
				</tr>

				<tr>
				<td colspan="1">هل المؤمن هو السائق</td>
				<td colspan="3">
				<?php
				if($Bn_Aga_Oth_Ins_Ind_Driver==0){
					echo "نعم" ;
				}else if($Bn_Aga_Oth_Ins_Ind_Driver==1){
					echo "لا" ;
					}
					?>
					</td>
				</tr>
				<?php } ?>


				 


				<!-- ////////////////////////////////////////////////////////////// -->
				<?php 

					
				if($show_driver_data == 1){	
					
				?>
				<tr>
				<td colspan="4"><h3>بيانات السائق</h3></td>
				</tr>

				<tr>
				<td >رقم الهوية</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Driver_Id_no; ?></td>
				<td >تاريخ الميلاد</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Driver_Birthdate; ?></td>
				</tr>
				<tr>
				<td >المهنة</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Driver_Work; ?></td>
				<td >جهة العمل</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Driver_Work_Place; ?></td>
				</tr>
				<tr>
				<td >المؤهل التعليمي</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Driver_Edication; ?></td>
				<td >الجنسية</td>
				<td ><?php echo $Bn_Aga_Oth_Ins_Driver_National; ?></td>
				</tr>

				<tr>
				<td >الجنس</td>
				<td ><?php
				if($Bn_Aga_Oth_Ins_Driver_Gender == 1 ){
					echo "ذكر" ;
				}else if($Bn_Aga_Oth_Ins_Driver_Gender == 2 ){
					echo "أنثي" ;
					}
				?></td>
				<td >الحالة الإجتماعية</td>
				<td ><?php
				if($Bn_Aga_Oth_Ins_Driver_Social == 1 ){
					echo "متزوج/ة" ;
				}else if($Bn_Aga_Oth_Ins_Driver_Social == 2 ){
					echo "مطلق/ة" ;
					}
				?></td>
				</tr>

				<tr>
				<td colspan="2">القيود الصحية</td>
				<td colspan="2"><?php
				if($Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has == 1 ){
					echo "نعم" ;
				}else if($Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has == 2 ){
					echo "لا" ;
					}
				?></td>
				</tr>

				<?php if($Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has == 1){  ?>
				<tr>
				<td colspan="2">القيد الصحي</td>
				<td colspan="2"><?php echo $Bn_Aga_Oth_Ins_Driver_Health_Constraint; ?></td>
				</tr>
				<?php } ?>
				<!-- //////////////////////////////////////////// -->





				<?php } ?>



				<!-- //////////////////////////////////////////// -->
				<tr>
				<td colspan="4"><h3>بيانات المركبة</h3></td>
				</tr>
				<tr>
				<td>الغرض من التامين</td>
				<td><?php echo $Bn_Sup_Ins_Vehicle_Purpose; ?></td>
				
				<td>الغرض من الاستخدام</td>
				<td><?php echo $Bn_Sup_Ins_Vehicle_Use; ?></td>
				</tr>
				<tr>
				<td>الرقم التسلسلي / الجمركي</td>
				<td colspan="3"><?php echo $Bn_Sup_Ins_Vehicle_HSCode; ?></td>
				</tr>
				<tr>
				<td >منطقة قيادة المركبة</td>
				<td ><?php echo $Bn_Sup_Ins_Vehicle_Area_Code; ?></td>
				<td >مدينة قيادة المركبة</td>
				<td ><?php echo $Bn_Sup_Ins_Vehicle_City_Code; ?></td>
				</tr>
				<tr>
				<td >سنة الصنع</td>
				<td colspan="3"><?php echo $Bn_Sup_Ins_Vehicle_Manufacturing_Year; ?></td>
				</tr>
			</table>

	    	<form method="post">
				<table class="table text-right" >
					<tr>
						<th class="text-center"><a href="W_Wep_Ins_Against_Others_Price_Data.php"><button type="button" id="back" class="btn btn-warning">   <- السابق  </button></a></th>
						<th class="text-center"><a href="W_Wep_Ins_Against_Others_Payment_Data.php"><button type="button" id="next" class="btn btn-info">  التالي -> </button></a></th>
					</tr>
				</table>

			</form>
			</div>

			<div class="col-md-4 col-sm-hide col-xs-hide float-right">
				<div class="panel panel-warning">
					<div class="panel-heading"> إرشادات الموقع</div>
					<div class="panel-body">



					</div>
				</div>
			</div>


		</div> <!-- end of panel body  -->
		<!-- </div> -->
	</div>
 <!-- end of the form 	 -->
</div>
</div>




<!--   ------------------------------------------ 3)------------------------------------     -->

<?php include('Footer.php');?>
		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   
