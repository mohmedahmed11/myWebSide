<?php
include_once("Header.php");

?>

<div class="side-rating">
  <a class="rateus" id="rateus-modle" href="#">قم بتقييمنا</a>
</div>

<div class="clearfix clearfix-space"></div>

<div class="row">
<div class="container">

  <div class="col-md-3 col-sm-6 col-xs-12 float-right">
    <!-- log in  -->
    <div class="home-login float-right text-center">
      <div class="labels">
        <div class="home"></div>
          <h3 class="account">الحساب الشخصي <i class="fa fa-lock fa-1x"></i> </h3>
      </div>
        <p class="links"><a>تسجيل دخول</a> | <a>تسجيل</a></p>
    </div>

    <div class="clearfix-space float-right"></div>

    <!-- our servise -->
    <div class="home-ourservices float-right" href="#">
        <p class="text">خدماتنا</p>
    </div>

    <div class="clearfix-space float-right"></div>

    <!-- insure aginest auther -->
    <div>
      <a class="home-othersinsurance home-use-defult our-hover float-right" href="W_Wep_Ins_Against_Others_Insured_Data.php"></a>
    </div>
  </div>

  <script src="https://github.com/videojs/video.js/issues/692"></script>

  <div class="col-md-9 col-sm-6 col-xs-12 float-right">
    <!-- main slaider -->
    <div class="home-slidercarousel home-use-defult-xsmall"> 
      <div class="carousel-inner slide-show" id="carousel-inner">
        <div class="carousel-item active">
        </div>
        <div class="carousel-item active">
          <img class="d-block w-100" src="images/carproductbg.png" alt="Second slide">
        </div>
        <div class="carousel-item">
          <!-- <img class="d-block w-100" src="..." alt="Third slide"> -->
        </div>
      </div>

      <!-- <div> -->
      <iframe id="video" class="vid" style="display:none;" width="100%" height="100%" src="" frameborder="0" allowfullscreen></iframe>
      <!-- <iframe class="vid hide" id="vid" width="420" height="315" src="https://www.youtube.com/embed/tgbNymZ7vqY?controls=0&autoplay=1" frameborder="0" allowfullscreen></iframe> -->
      <!-- </div> -->
      <!-- <iframe class="vid hide" id="vid" src="https://www.youtube.com/watch?v=KHe6ZDH5mvY" frameborder="0" allowfullscreen></iframe> -->
    </div>
  </div>
    
    
    
</div>
</div>


<div class="clearfix clearfix-space"></div>
<div class="row">
<div class="container">
  <!-- <div class="containerbody"> -->

  <div class="col-md-3 col-sm-6 col-xs-12 float-right">
  <a class="" href="#">
      <img class="home-passengers home-use-defult home-use-defult-small home-use-defult-xsmall">
    </a>
    <a class="" href="#">
      <img style="margin-top: 13px;" class="home-fullinsurance home-use-defult home-use-defult-xsmall home-use-defult-small">
    </a>
  </div>

  <div class="col-md-3 col-sm-6 col-xs-12 float-right">
    <a class="" href="#" id="play-video">
     <img class="home-healthinsurance home-use-defult home-use-defult-xsmall">
  </a>
  </div>

  <div class="col-md-3 col-sm-6 col-xs-12 float-right">
    <a class="" href="#">
      <img class="home-recentreports home-use-defult home-use-defult-xsmall">
    </a>
  </div>

  <div class="col-md-3 col-sm-6 col-xs-12 float-right">
    <a class="" href="#">
      <img class="home-recentorders home-use-defult home-use-defult-xsmall">
    </a>
  </div>

  

<!-- </div> -->

</div>
</div>


<div class="modal" style="color:#333;  text-align:center;    background-color: rgba(0, 0, 0, .5);" id="modal"  role="dialog">
  <div class="modal-dialog" style="margin: 10% auto;" role="document">
    <div class="modal-content">
      <div class="modal-header" >
        <h5 class="modal-title">قم بتقييمنا</h5>
        
      </div>
      <div class="modal-body" style="color:#ccc;">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span>
        <span class="fa fa-star"></span>
      </div>
      <div class="modal-footer" style="text-align:center;">
        <button type="button" class="btn btn-primary close-me">حفظ</button> || 
        <button type="button" class="btn btn-secondary close-me" data-dismiss="modal">إلغاء</button>
      </div>
    </div>
  </div>
</div>


<?php

include_once("Footer.php")

?>

<style>

.checked {
  color: orange;
}

</style>

<script>

$("#rateus-modle").click(function(){
  $("#modal").show();
});

$("#modal .close-me").click(function(){
  $("#modal").hide();
});

// $("#play-vedio").click(function(){
//   display();
// });

</script>

