<?php
include_once("Header.php");

if(@$_SESSION['status']!=1){
	// echo "<script>location.href='index.php';</script>";
}


$Bn_Aga_Oth_Ins_Phone_No = '';
$Bn_Aga_Oth_Ins_Acount_No = '';
$Bn_Aga_Oth_Ins_Acount_Email = '';
$Bn_Aga_Oth_Ins_Deliver = '';

if (isset($_COOKIE['Bn_Aga_Oth_Ins'])) {
	
	if (isset($_COOKIE['Bn_Aga_Oth_Ins_Payment'])) {
		$Bn_Aga_Oth_Ins_Payment = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Payment']);
		$Bn_Aga_Oth_Ins_Phone_No = $Bn_Aga_Oth_Ins_Payment->Bn_Aga_Oth_Ins_Phone_No;
		$Bn_Aga_Oth_Ins_Acount_No = $Bn_Aga_Oth_Ins_Payment->Bn_Aga_Oth_Ins_Acount_No;
		$Bn_Aga_Oth_Ins_Acount_Email = $Bn_Aga_Oth_Ins_Payment->Bn_Aga_Oth_Ins_Acount_Email;
		$Bn_Aga_Oth_Ins_Deliver = $Bn_Aga_Oth_Ins_Payment->Bn_Aga_Oth_Ins_Deliver;
	}

}else {
	echo "<script>location.href='W_Wep_Main_Menu.php';</script>";
}

?>
<!-- -->

<!--   -------------------------------------1) ----------------------------------------   -->



<!--   -----------------------------------------------------------------------------   -->

<div class="clearfix clearfix-space"></div>
<!--   ---------------------------------------------2)--------------------------------   -->

<div class="row" style="margin:0px auto;">
<div class="container">
 <!-- begin of the form 	 -->
 	<div class="panel panel-default">
	 	<div class="panel-heading"> <h4> تامين ضد الغير </h4> </div>

		<div class="panel-body">

			<!-- steps style -->
			<div class="row">
			<div class="container">

				<div class="against-other-steps">
					<a href="#"><img class="step" src="img/Step1.png"></a>
					<a href="#"><img class="step" src="img/Step2.png"></a>
					<a href="#"><img class="step" src="img/Step3.png"></a>
					<a href="#"><img class="step" src="img/Step4.png"></a>
					<a href="#"><img class="step" src="img/Step5.png"></a>
					<a href="#"><img class="step" src="img/Step6.png"></a>
					<a href="#"><img class="step" src="img/Step7-a.png"></a>
					<a href="#"><img class="step" src="img/Step8.png"></a>
				</div>
				</div>
			</div>


			<!-- end steps -->
			<div class="clearfix clearfix-space"></div>
			
			<div class="col-md-8 col-sm-12 col-xs-12 float-right">
		
		
			<form id="myForm" method="post">
			<input type="hidden" name="Bn_Aga_Oth_Ins_Code" value="<?php //echo htmlentities($_GET['Bn_Aga_Oth_Ins_Code']);?>">
			<table class="table">

				<tr>
					<th colspan="2" class="text-center"><h3>الدفع</h3></th>
				</tr>
				<tr>
					<th colspan="2" class="text-center"><p>عزيزي......الرجاء تزويدنا بقنوات الاتصال والدفع لاستكمال اجراءات اصدار الوثيقة</p></th>
				</tr>

				<tr>
				<td>رقم الجوال	</td>
				<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-phone"></i></span>
							<input type="text" class="form-control" name="Bn_Aga_Oth_Ins_Phone_No" id="Bn_Aga_Oth_Ins_Phone_No" value="<?php echo $Bn_Aga_Oth_Ins_Phone_No;?>" placeholder="رقم الجوال" aria-describedby="basic-addon1">
						</div></td>
				</tr>
				<tr>
				<td >رقم الحساب البنكي</td>
				<td ><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-credit-card"></i></span>
							<input type="text" class="form-control" name="Bn_Aga_Oth_Ins_Acount_No" id="Bn_Aga_Oth_Ins_Acount_No" value="<?php echo $Bn_Aga_Oth_Ins_Acount_No;?>" placeholder="رقم الحساب البنكي" aria-describedby="basic-addon1">
						</div></td>
				</tr>
				<tr>
				<td>البريد الالكتروني</td>
				<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-at"></i></span>
							<input type="email" class="form-control" name="Bn_Aga_Oth_Ins_Acount_Email" id="Bn_Aga_Oth_Ins_Acount_Email" value="<?php echo $Bn_Aga_Oth_Ins_Acount_Email;?>" placeholder="البريد الالكتروني" aria-describedby="basic-addon1">
						</div></td>
				</tr>
				<tr>
				<td colspan="2" ><input type="checkbox" name="Bn_Aga_Oth_Ins_Deliver" <?php if($Bn_Aga_Oth_Ins_Deliver == '1') { echo "checked" ; } ?> value="1" > هل ترغب بتوصيل الوثيقة الى العنوان المرفق </td>
				</tr>
			</table>
			<table class="table text-right" >
					<tr>
						<input type="hidden" name="confirm-action" value="Bn_Aga_Oth_Payment_confirm">
						<th class="text-center"><a href="W_Wep_Ins_Against_Others_Check_Document_Data.php"><button type="button" id="back" class="btn btn-warning">   <- السابق  </button></a></th>
						<!-- <th class="text-center"><a href="W_Wep_Ins_Against_Others_Check_Document_Issuance.php"><button type="button" id="next" class="btn btn-info">  التالي -> </button></a></th> -->
						<th class="text-center"><a href="#"><button type="button" id="next" class="btn btn-info">  التالي -> </button></a></th>
					</tr>
				</table>

			</form>
			</div>

			<div class="col-md-4 col-sm-hide col-xs-hide float-right">
				<div class="panel panel-warning">
					<div class="panel-heading"> إرشادات الموقع</div>
					<div class="panel-body">



					</div>
				</div>
			</div>


		</div> <!-- end of panel body  -->
		<!-- </div> -->
	</div>
 <!-- end of the form 	 -->
</div>
</div>




<!--   ------------------------------------------ 3)------------------------------------     -->

<?php include('Footer.php');?>
		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   


<!--   ------------------------------------------ 3)------------------------------------     -->

<script>

	$("#next").click(function(){

		var check = 0;
		if($("#Bn_Aga_Oth_Ins_Phone_No").val() == ''){
			$("#Bn_Aga_Oth_Ins_Phone_No").addClass("alert-danger");
			check = 1;
		}

		if($("#Bn_Aga_Oth_Ins_Acount_No").val() == ''){
			$("#Bn_Aga_Oth_Ins_Acount_No").addClass("alert-danger");
			check = 1;
		}

		if($("#Bn_Aga_Oth_Ins_Acount_Email").val() == ''){
			$("#Bn_Aga_Oth_Ins_Acount_Email").addClass("alert-danger");
			check = 1;
		}       

		if(check == 0){

			$.confirm({
				title: 'تحقق!',
				content: 'هل أنت متأكد من صحة البيانات التي قدمتها !!',
				buttons: {
					confirm: function () {
						$("#myForm").submit();
					},
					cancel: function () {
						$.alert('Canceled!');
					}
				}
			});

		}else{
			$.alert({
				title: 'تنبيه!',
				content: 'عفوا يجب ملئ جميع الحقول المطلوبة !!',
			});
		}
		

		//$("#myForm").submit();
		
	});

	$(document).on("submit", "#myForm", function(event)
	{
		event.preventDefault(); 

		$('.loading-overlay').show();
		$('.view-loading-overlay').loading({ circles: 3,overlay: true });
		
		var formData = new FormData(this);

        $.ajax({
            type:'POST',
            url: 'application/confirm.php',
            data: formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
				setTimeout(() => {
					$('.loading-overlay').hide();
					if(data == true){

						location.href='W_Wep_Ins_Against_Others_Check_Document_Issuance.php';
						console.log(data);
						
					}else{
						$.alert({
							title: 'تنبيه!',
							content: 'فشلت العملية حاول مرة أخري !!',
						});
					}
                }, 500);
            },
            error: function(data){
                console.log(data);
            }
		});
		
       

		return false;
	});
	 
	 
 </script>   
		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   

 
                
             
	