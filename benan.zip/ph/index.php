<!DOCTYPE html>
<html dir="rtl">
<?php
   ob_start();
   session_start();
?>

<head>

  <meta charset="UTF-8">

  <title>benanteam - Login </title>

  <link rel="stylesheet" href="css/reset.css">

    <link rel="stylesheet" href="css/style3.css" media="screen" type="text/css" />

</head>

<body>

  <div class="wrap">
		<div class="avatar">
      <img src="images/logo.png">
        </div>
		
		
		
		
		
		
        <form  action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method = "post">	

            	<input  name="username" type="text" placeholder="اسم المستخدم" required  value="<?php if(isset($_COOKIE["member_login"])) { echo $_COOKIE["member_login"]; } ?>">
		<div class="bar">
			<i></i>
		</div>
		<input type="password" name="password"  placeholder="كلمة المرور" required value="<?php if(isset($_COOKIE["member_password"])) { echo $_COOKIE["member_password"]; } ?>">
		
        <button name="login"  type = "submit" >تسجيل الدخول</button>
<div class="field-group">
		<div>
		<label for="remember-me">تزكرني؟</label>
		<input type="checkbox" name="remember" id="remember" <?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?> />
	</div>
    </div>
	
	
    </form>

	

	<?php
	$msg = '';
	
	if (isset($_POST['login']) && !empty($_POST['username']) 
		 && !empty($_POST['password'])) {

		 if ($_POST['username'] == 'admin' && 
				$_POST['password'] == '142536') {
				$_SESSION['valid'] = true;
				$_SESSION['status']=1;
				$_SESSION['timeout'] = time();
				$_SESSION['username'] = 'admin';
				
				
				
				if(!empty($_POST["remember"])) {
				setcookie ("member_login",$_POST["member_name"],time()+ (10 * 365 * 24 * 60 * 60));
				setcookie ("member_password",$_POST["member_password"],time()+ (10 * 365 * 24 * 60 * 60));
			} else {
				if(isset($_COOKIE["member_login"])) {
					setcookie ("member_login","");
				}
				if(isset($_COOKIE["member_password"])) {
					setcookie ("member_password","");
				}
			}
			header("Location: W_Wep_Main_Menu.php", true, 301);
exit();
            		 }else {
                $msg = 'اسم المستخدم او كلمة المرور غير صحيحة';
				
				                ?>
<div style="font" class="error">
 <font color="red"> 
 <b>
<?php
                echo"$msg";
			
                ?>
                	</b>
				</font>
                </div> 
                <?php
		 }
	}
?>


</body>

</html>