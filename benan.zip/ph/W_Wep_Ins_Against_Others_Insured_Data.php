﻿<?php include_once('Header.php') ?>
<?php
include_once("Hijri_date.php");
// include_once 'conn.php';

if(@$_SESSION['status']!=1){
	// echo "<script>location.href='index.php';</script>";
}

$Bn_Aga_Oth_Ins_Start_Date = "";


if(isset($_POST['Next'])){
	
	
	// $bn_w_Increment_sql="SELECT `AUTO_INCREMENT` FROM  INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'cl60-benan' AND   TABLE_NAME   = 'bn_against_others_insurance_data'";
	// $bn_w_Increment_result=mysql_query($bn_w_Increment_sql);
	// $bn_w_Increment_row=mysql_fetch_assoc($bn_w_Increment_result);
	
	
	// $Bn_Aga_Oth_Ins_Start_Date=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Start_Date']);
	// $Bn_Aga_Oth_Ins_End_Date=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_End_Date']);
	// $Bn_Sup_Sector_Code=mysql_real_escape_string($_POST['Bn_Sup_Sector_Code']);
	// $Bn_Aga_Oth_Ins_Id_No=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Id_No']);
	// $Bn_Aga_Oth_Ins_Birthdate=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Birthdate']);
	// $Bn_Aga_Oth_Ins_Main_Driver=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Main_Driver']);
	// $Bn_Aga_Oth_Ins_Employer=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Employer']);
	// $Bn_Sup_Nationality_Code=mysql_real_escape_string($_POST['Bn_Sup_Nationality_Code']);
	// $Bn_Sup_Gender_Code=mysql_real_escape_string($_POST['Bn_Sup_Gender_Code']);
	// $Bn_Sup_Jobs_Code=mysql_real_escape_string($_POST['Bn_Sup_Jobs_Code']);
	// $Bn_Sup_Edu_Qua_Code=mysql_real_escape_string($_POST['Bn_Sup_Edu_Qua_Code']);
	
    // $bn_w_sql="INSERT INTO `bn_against_others_insurance_data` (`Bn_Aga_Oth_Ins_Start_Date`, `Bn_Aga_Oth_Ins_End_Date`, `Bn_Sup_Sector_Code`, `Bn_Aga_Oth_Ins_Id_No`, `Bn_Aga_Oth_Ins_Birthdate`, `Bn_Aga_Oth_Ins_Main_Driver`, `Bn_Aga_Oth_Ins_Employer`, `Bn_Sup_Nationality_Code`, `Bn_Sup_Gender_Code`, `Bn_Sup_Jobs_Code`, `Bn_Sup_Edu_Qua_Code`) 
	// VALUES ('$Bn_Aga_Oth_Ins_Start_Date', '$Bn_Aga_Oth_Ins_End_Date', '$Bn_Sup_Sector_Code', '$Bn_Aga_Oth_Ins_Id_No', '$Bn_Aga_Oth_Ins_Birthdate', '$Bn_Aga_Oth_Ins_Main_Driver', '$Bn_Aga_Oth_Ins_Employer', '$Bn_Sup_Nationality_Code', '$Bn_Sup_Gender_Code', '$Bn_Sup_Jobs_Code', '$Bn_Sup_Edu_Qua_Code')";
	// 	$bn_w_result=mysql_query($bn_w_sql);
		
	// if($bn_w_result){
	// echo "<script>location.href='W_Wep_Ins_Against_Others_Driver_Data.php?Bn_Aga_Oth_Ins_Code=$bn_w_Increment_row[AUTO_INCREMENT]';</script>";
	// }
	// else{
	// //exit;	
	// }
}

?>

<!-- -->


<!-- Header -->

<!-- End Header -->

<!-- Main Image Slider -->
 
<!--   -------------------------------------1) ----------------------------------------   -->



<!--   -----------------------------------------------------------------------------   -->


<div class="clearfix clearfix-space"></div>
<!--   ---------------------------------------------2)--------------------------------   -->

<div class="row" style="margin:0px auto;">
<div class="container">
 <!-- begin of the form 	 -->
 	<div class="panel panel-default">
	 	<div class="panel-heading"> <h4> تامين ضد الغير </h4> </div>

		<div class="panel-body">

			<!-- steps style -->
			<div class="row">
			<div class="container">
				
				<div class="against-other-steps">
					<a href="#"><img class="step" src="img/Step1-a.png"></a>
					<a href="#"><img class="step" src="img/Step2.png"></a>
					<a href="#"><img class="step" src="img/Step3.png"></a>
					<a href="#"><img class="step" src="img/Step4.png"></a>
					<a href="#"><img class="step" src="img/Step5.png"></a>
					<a href="#"><img class="step" src="img/Step6.png"></a>
					<a href="#"><img class="step" src="img/Step7.png"></a>
					<a href="#"><img class="step" src="img/Step8.png"></a>
				</div>
			</div>
			</div>
			<!-- end steps -->
			<div class="clearfix clearfix-space"></div>
			
			<div class="col-md-8 col-sm-12 col-xs-12 float-right">
			<form id="myForm" enctype="multipart/form-data">
			<table class="table text-right" >
				<tr>
					<th colspan="2" class="text-right">بيانات المؤمن</th>
				</tr>
				<tr>
					<td><div class="input-group">
						<span class="input-group-addon" id="basic-addon1"><i class="fa fa-calendar"></i></span>
						<input type="text" id="date" name="Bn_Aga_Oth_Ins_Start_Date_show" value="<?php echo date('Y-m-d'); ?>" class="form-control disabled" disabled placeholder="Username" aria-describedby="basic-addon1">
						<input type="hidden" id="date1" name="Bn_Aga_Oth_Ins_Start_Date" value="<?php echo date('Y-m-d'); ?>" class="form-control disabled" placeholder="Username" aria-describedby="basic-addon1">
					</div></td>
					<td>
					<div class="input-group">
						<span class="input-group-addon" id="basic-addon1"><i class="fa fa-puzzle-piece"></i></span>
						<select name="Bn_Sup_Sector_Code" class="form-control select-style" id="Bn_Sup_Sector_Code" aria-describedby="basic-addon1">
						<option value="free" selected >اختيار القطاع</option>
						<option value="genaral">القطاع الحكومي</option>
						<option value="spacial">القطاع الخاص</option>
						<option value="individuals">قطاع الأفراد</option>
					</select>
				</div></td>
				</tr>

				</table>

				<table class="table text-right" id="genaral" style="display:none;">
				<!-- <div class="genaral-section hide"> -->
					<tr>
						<th colspan="2" class="text-center">القطاع الحكومي</th>
					</tr>
					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-info"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Gov_No" id="Bn_Aga_Oth_Ins_Gov_No" class="form-control" placeholder="الرقم الحكومي" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-italic"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Gov_Id_No" id="Bn_Aga_Oth_Ins_Gov_Id_No" class="form-control" placeholder="رقم التفويض" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-certificate"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Gov_Id_Name" id="Bn_Aga_Oth_Ins_Gov_Id_Name" class="form-control" placeholder="هوية التفويض" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-calendar-plus-o"></i></span>
							<input data-date-format="mm/dd/yyyy" name="Bn_Aga_Oth_Ins_Gov_Id_Date" id="Bn_Aga_Oth_Ins_Gov_Id_Date" class="form-control datepicker-genaral" placeholder="تاريخ التفويض" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-file-image-o"></i></span>
							<input type="text" id="Bn_Aga_Oth_Ins_Gov_Id_Image_View" class="form-control" id="choose-file-genaral" placeholder="صورة التفويض" aria-describedby="basic-addon1">
							<input type="file" name="Bn_Aga_Oth_Ins_Gov_Id_Image" id="Bn_Aga_Oth_Ins_Gov_Id_Image" class="form-control choose-file-target" id="is-choose-file-genaral" placeholder="صورة التفويض" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1">?</span>
							<select name="Bn_Aga_Oth_Ins_Gov_Driver" id="Bn_Aga_Oth_Ins_Gov_Driver" class="form-control select-style" aria-describedby="basic-addon1">
								<option value="0" selected >إضافة سائق</option>
								<option value="1">نعم</option>
								<option value="2">لا</option>
							</select>
						</div></td>
					</tr>

				<!-- </div> -->
				</table>

				<table class="table text-right" id="spacial" style="display:none;">
				<!-- <div class="spasial-section hide"> -->
					<tr>
						<th colspan="2" class="text-center">القطاع الخاص</th>
					</tr>
					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-info"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Spe_No" id="Bn_Aga_Oth_Ins_Spe_No" class="form-control" placeholder="الرقم التجاري" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-italic"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Spe_Id_No" id="Bn_Aga_Oth_Ins_Spe_Id_No" class="form-control" placeholder="رقم التفويض" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-certificate"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Spe_Id_Name" id="Bn_Aga_Oth_Ins_Spe_Id_Name" class="form-control" placeholder="هوية التفويض" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-calendar-plus-o"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Spe_Id_Date" id="Bn_Aga_Oth_Ins_Spe_Id_Date" class="form-control datepicker-spacial" placeholder="تاريخ التفويض" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-file-image-o"></i></span>
							<input type="text" class="form-control" id="Bn_Aga_Oth_Ins_Spe_Id_Image_View" id="choose-file-spacial" placeholder="صورة التفويض" aria-describedby="basic-addon1">
							<input type="file" name="Bn_Aga_Oth_Ins_Spe_Id_Image" id="Bn_Aga_Oth_Ins_Spe_Id_Image" class="form-control choose-file-target" id="is-choose-file-spacial" placeholder="صورة التفويض" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1">?</span>
							<select name="Bn_Aga_Oth_Ins_Spe_Driver" id="Bn_Aga_Oth_Ins_Spe_Driver" class="form-control select-style" aria-describedby="basic-addon1">
								<option value="0" selected >إضافة سائق</option>
								<option value="1">نعم</option>
								<option value="2">لا</option>
							</select>
						</div></td>
					</tr>

				<!-- </div> -->
				</table>

				<table class="table text-right" id="individuals" style="display:none;">
				<!-- <div class="Individuals-section hide"> -->
					<tr>
						<th colspan="2" class="text-center">قطاع الأفراد</th>
					</tr>
					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-info"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Ind_no" id="Bn_Aga_Oth_Ins_Ind_no" class="form-control" placeholder="رقم الهوية" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-calendar-plus-o"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Ind_Birth_Date" id="Bn_Aga_Oth_Ins_Ind_Birth_Date" class="form-control datepicker" placeholder="تاريخ الميلاد" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-certificate"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Ind_Work" id="Bn_Aga_Oth_Ins_Ind_Work" class="form-control" placeholder="المهنة" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-briefcase"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Ind_Job" id="Bn_Aga_Oth_Ins_Ind_Job" class="form-control" placeholder="الوظيفة" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-building-o"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Ind_Work_Place" id="Bn_Aga_Oth_Ins_Ind_Work_Place" class="form-control" placeholder="جهة العمل" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-calendar-plus-o"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Ind_National" id="Bn_Aga_Oth_Ins_Ind_National" class="form-control" placeholder="الجنسية" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>

						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-transgender"></i></span>
							<select name="Bn_Aga_Oth_Ins_Ind_Gender" id="Bn_Aga_Oth_Ins_Ind_Gender" class="form-control select-style" aria-describedby="basic-addon1">
								<option value="0" selected >الجنس</option>
								<option value="1">نعم</option>
								<option value="2">لا</option>
							</select>
						</div></td>

						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-mars-stroke-h"></i></span>
							<select name="Bn_Aga_Oth_Ins_Ind_Social" id="Bn_Aga_Oth_Ins_Ind_Social" class="form-control select-style" aria-describedby="basic-addon1">
								<option value="0" selected >الحالة الإجتماعية</option>
								<option value="1">نعم</option>
								<option value="2">لا</option>
							</select>
						</div></td>
						
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1" style="height: 34px;">هل المؤمن هو السائق الرئيسي</span>
						
						</div></td>
						<td><div class="input-group" style="width: 100%">
							<!-- <span class="input-group-addon" id="basic-addon1">?</span> -->
							<select name="Bn_Aga_Oth_Ins_Ind_Driver" id="Bn_Aga_Oth_Ins_Ind_Driver" class="form-control select-style" aria-describedby="basic-addon1">
								<option value="0" selected >إختر الإجابة</option>
								<option value="1">نعم</option>
								<option value="2">لا</option>
							</select>
						</div></td>
					</tr>

				<!-- </div> -->
				</table>



				<table class="table text-right" >
					<tr>
						<input type="hidden" name="confirm-action" value="Bn_Aga_Oth_Ins_confirm">
						<th class="text-center"><a href="#"><button type="button" id="next" class="btn btn-info">  التالي -> </button></a></th>
					</tr>
				</table>

			


			<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				
			</div><!-- /.col-lg-6 -->
			</div><!-- /.row -->
			
			</form>
			</div>


			<div class="col-md-4 col-sm-hide col-xs-hide float-right">
				<div class="panel panel-warning">
					<div class="panel-heading"> إرشادات الموقع</div>
					<div class="panel-body">



					</div>
				</div>
			</div>


		
		</div> <!-- end of panel body  -->
	<!-- </div> -->
	</div>
 <!-- end of the form 	 -->
</div>
</div>
				            
				
			



<!--   ------------------------------------------ 3)------------------------------------     -->

 <!-- 1- Load the moment-with-locales -->

		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   
            
             
	


<!-- Footer -->
	<?php include('Footer.php');?>
<!-- End Footer -->


 <script>
	 $("#Bn_Aga_Oth_Ins_Gov_Id_Image").change(function(){
		var val = this.files[0].name;
		$('#Bn_Aga_Oth_Ins_Gov_Id_Image_View').val(val);
		return false;
	 });

	 $("#Bn_Aga_Oth_Ins_Spe_Id_Image").change(function(){
		var val = this.files[0].name;
		$('#Bn_Aga_Oth_Ins_Spe_Id_Image_View').val(val);
		return false;
	 });

	 $('.datepicker-genaral').datepicker();
	 $('.datepicker-spacial').datepicker();
	 $('.datepicker').datepicker();


	 $("#Bn_Sup_Sector_Code").change(function(){
		 var val = $(this).val();

		 if ( val == "genaral" ) {
			$("#genaral").fadeIn(500);
			$("#spacial").hide();
			$("#individuals").hide();
		 } else if ( val === "spacial" ) {
			$("#genaral").hide();
			$("#spacial").fadeIn(500);
			$("#individuals").hide();
		 } else if ( val === "individuals" ) {
			$("#genaral").hide();
			$("#spacial").hide();
			$("#individuals").fadeIn(500);
		 } else {
			$("#genaral").hide();
			$("#spacial").hide();
			$("#individuals").hide();
		 }

		 return false;
	 });


	 $("#next").click(function(){

			if($("#Bn_Sup_Sector_Code").val() == "free"){
				$.alert({
					title: 'تنبيه!',
					content: 'يجب إختيار القطاع اولاً !!',
				});
			}else{
				var Bn_Sup_Sector_Code = $("#Bn_Sup_Sector_Code").val();
				if(Bn_Sup_Sector_Code == "genaral") {
					// name="Bn_Aga_Oth_Ins_Ind_Driver"
					//alert("1");
					var check = 0;

					if($("#Bn_Aga_Oth_Ins_Gov_No").val() == ''){
						$("#Bn_Aga_Oth_Ins_Gov_No").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Gov_Id_No").val() == ''){
						$("#Bn_Aga_Oth_Ins_Gov_Id_No").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Gov_Id_Name").val() == ''){
						$("#Bn_Aga_Oth_Ins_Gov_Id_Name").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Gov_Id_Date").val() == ''){
						$("#Bn_Aga_Oth_Ins_Gov_Id_Date").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Gov_Id_Image").val() == ''){
						$("#Bn_Aga_Oth_Ins_Gov_Id_Image_View").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Gov_Driver").val() == 0){
						$("#Bn_Aga_Oth_Ins_Gov_Driver").addClass("alert-danger");
						check = 1;
					}

				}else if(Bn_Sup_Sector_Code == "spacial") {
					// alert("2");
					var check = 0;

					if($("#Bn_Aga_Oth_Ins_Spe_No").val() == ''){
						$("#Bn_Aga_Oth_Ins_Spe_No").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Spe_Id_No").val() == ''){
						$("#Bn_Aga_Oth_Ins_Spe_Id_No").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Spe_Id_Name").val() == ''){
						$("#Bn_Aga_Oth_Ins_Spe_Id_Name").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Spe_Id_Date").val() == ''){
						$("#Bn_Aga_Oth_Ins_Spe_Id_Date").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Spe_Id_Image").val() == ''){
						$("#Bn_Aga_Oth_Ins_Spe_Id_Image_View").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Spe_Driver").val() == 0){
						$("#Bn_Aga_Oth_Ins_Spe_Driver").addClass("alert-danger");
						check = 1;
					}

				} if(Bn_Sup_Sector_Code == "individuals") {
					// alert("3");
					var check = 0;
					if($("#Bn_Aga_Oth_Ins_Ind_no").val() == ''){
						$("#Bn_Aga_Oth_Ins_Ind_no").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Ind_Birth_Date").val() == ''){
						$("#Bn_Aga_Oth_Ins_Ind_Birth_Date").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Ind_Work").val() == ''){
						$("#Bn_Aga_Oth_Ins_Ind_Work").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Ind_Job").val() == ''){
						$("#Bn_Aga_Oth_Ins_Ind_Job").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Ind_Work_Place").val() == ''){
						$("#Bn_Aga_Oth_Ins_Ind_Work_Place").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Ind_National").val() == ''){
						$("#Bn_Aga_Oth_Ins_Ind_National").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Ind_Gender").val() == 0){
						$("#Bn_Aga_Oth_Ins_Ind_Gender").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Ind_Social").val() == 0){
						$("#Bn_Aga_Oth_Ins_Ind_Social").addClass("alert-danger");
						check = 1;
					}

					if($("#Bn_Aga_Oth_Ins_Ind_Driver").val() == 0){
						$("#Bn_Aga_Oth_Ins_Ind_Driver").addClass("alert-danger");
						check = 1;
					}
				}

				if(check == 0){

					$("#myForm").submit();
				}else{
					$.alert({
						title: 'تنبيه!',
						content: 'عفوا يجب ملئ جميع الحقول المطلوبة !!',
					});
				}
			}
	 });

	 $(document).on("submit", "#myForm", function()
	{
		// event.preventDefault();   
		var Bn_Sup_Sector_Code = $("#Bn_Sup_Sector_Code").val();
		var formData = new FormData(this);

        $.ajax({
            type:'POST',
            url: 'application/confirm.php',
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){

				if(data == true){

					if(Bn_Sup_Sector_Code == "genaral") {
						// name="Bn_Aga_Oth_Ins_Ind_Driver"
						//alert("1");
						if($("#Bn_Aga_Oth_Ins_Gov_Driver").val() == 1){
							location.href='W_Wep_Ins_Against_Others_Driver_Data.php';
						}else if($("#Bn_Aga_Oth_Ins_Gov_Driver").val() == 2){
							location.href='W_Wep_Ins_Against_Others_Vehicle_Data.php';
						}

					}else if(Bn_Sup_Sector_Code == "spacial") {
						// alert("2");
						if($("#Bn_Aga_Oth_Ins_Spe_Driver").val() == 1){
							location.href='W_Wep_Ins_Against_Others_Driver_Data.php';
						}else if($("#Bn_Aga_Oth_Ins_Spe_Driver").val() == 2){
							location.href='W_Wep_Ins_Against_Others_Vehicle_Data.php';
						}

					} if(Bn_Sup_Sector_Code == "individuals") {
						// alert("3");
						if($("#Bn_Aga_Oth_Ins_Ind_Driver").val() == 1){
							location.href='W_Wep_Ins_Against_Others_Vehicle_Data.php';
						}else if($("#Bn_Aga_Oth_Ins_Ind_Driver").val() == 2){
							location.href='W_Wep_Ins_Against_Others_Driver_Data.php';
						}
					}
					console.log(data);
				}else{
					console.log(data);
				}
                
            },
            error: function(data){
                console.log(data);
            }
		});
		
       

		return false;
	});
	 
 </script>   
 
 <script src="http://momentjs.com/downloads/moment-with-locales.min.js"></script>
    <script src="https://raw.githubusercontent.com/xsoh/moment-hijri/master/moment-hijri.js"></script>
    
    <script>
      moment.locale('ar-SA');// 2- Set the global locale to `ar-SA`
      m = moment();
      m.format('iYYYY/iM/iDهـ الموافق YYYY/M/Dم'); //3- use it normally 

	//   $("#date").val(m);
      //١٤٣٧/٨/١٧هـ الموافق ٢٠١٦/٥/٢٤م
	</script>
	

<style>



</style>