<?php include_once('Header.php') ?>
<?php
// if(@$_SESSION['status']!=1){
// 	echo "<script>location.href='index.php';</script>";
// }

// if(isset($_POST['Next'])){
	
// 	$Bn_Aga_Oth_Ins_Code=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Code']);
// 	$Bn_Aga_Oth_Ins_Id_No_Driver=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Id_No_Driver']);
// 	$Bn_Aga_Oth_Ins_Birthdate_Driver=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Birthdate_Driver']);
// 	$Bn_Aga_Oth_Ins_Employer_Driver=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Employer_Driver']);
// 	$Bn_Sup_Jobs_Code_Driver=mysql_real_escape_string($_POST['Bn_Sup_Jobs_Code_Driver']);
// 	$Bn_Sup_Edu_Qua_Code_Driver=mysql_real_escape_string($_POST['Bn_Sup_Edu_Qua_Code_Driver']);
// 	$Bn_Aga_Oth_Ins_Main_Driver=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Main_Driver']);
// 	$Bn_Sup_Nationality_Code_Driver=mysql_real_escape_string($_POST['Bn_Sup_Nationality_Code_Driver']);
// 	$Bn_Sup_Gender_Code_Driver=mysql_real_escape_string($_POST['Bn_Sup_Gender_Code_Driver']);
// 	$Bn_Aga_Oth_Ins_Health_Constraint=mysql_real_escape_string($_POST['Bn_Aga_Oth_Ins_Health_Constraint']);
// 	$Bn_Req_Insured_Hth_Res_No=mysql_real_escape_string($_POST['Bn_Req_Insured_Hth_Res_No']);
	
//      $bn_w_sql="UPDATE `bn_against_others_insurance_data` SET 
// 	`Bn_Aga_Oth_Ins_Id_No_Driver` = '$Bn_Aga_Oth_Ins_Id_No_Driver',
// 	`Bn_Aga_Oth_Ins_Birthdate_Driver` = '$Bn_Aga_Oth_Ins_Birthdate_Driver',
// 	`Bn_Aga_Oth_Ins_Employer_Driver` = '$Bn_Aga_Oth_Ins_Employer_Driver',
// 	`Bn_Sup_Jobs_Code_Driver` = '$Bn_Sup_Jobs_Code_Driver',
// 	`Bn_Sup_Edu_Qua_Code_Driver` = '$Bn_Sup_Edu_Qua_Code_Driver',
// 	`Bn_Sup_Nationality_Code_Driver` = '$Bn_Sup_Nationality_Code_Driver',
// 	`Bn_Sup_Gender_Code_Driver` = '$Bn_Sup_Gender_Code_Driver',
// 	`Bn_Aga_Oth_Ins_Health_Constraint` = '$Bn_Aga_Oth_Ins_Health_Constraint',
// 	`Bn_Req_Insured_Hth_Res_No`='$Bn_Req_Insured_Hth_Res_No'
// 	WHERE `Bn_Aga_Oth_Ins_Code` = $Bn_Aga_Oth_Ins_Code";
// 		$bn_w_result=mysql_query($bn_w_sql);
		
// 	if($bn_w_result){
// 	echo "<script>location.href='W_Wep_Ins_Against_Others_Vehicle_Data.php?Bn_Aga_Oth_Ins_Code=$Bn_Aga_Oth_Ins_Code';</script>";
// 	}
// 	else{
// 	//exit;	
// 	}
// }

?>
<!-- -->

<!--   -------------------------------------1) ----------------------------------------   -->



<!--   -----------------------------------------------------------------------------   -->


<div class="clearfix clearfix-space"></div>
<!--   ---------------------------------------------2)--------------------------------   -->

<div class="row" style="margin:0px auto;">
<div class="container">
 <!-- begin of the form 	 -->
 	<div class="panel panel-default">
	 	<div class="panel-heading"> <h4> تامين ضد الغير </h4> </div>

		<div class="panel-body">

			<!-- steps style -->
			<div class="row">
			<div class="container">

				<div class="against-other-steps">

					<a href="#"><img class="step" src="img/Step1.png"></a>
					<a href="#"><img class="step" src="img/Step2-a.png"></a>
					<a href="#"><img class="step" src="img/Step3.png"></a>
					<a href="#"><img class="step" src="img/Step4.png"></a>
					<a href="#"><img class="step" src="img/Step5.png"></a>
					<a href="#"><img class="step" src="img/Step6.png"></a>
					<a href="#"><img class="step" src="img/Step7.png"></a>
					<a href="#"><img class="step" src="img/Step8.png"></a>
				</div>
			</div>
			</div>


			<!-- end steps -->
			<div class="clearfix clearfix-space"></div>
			
			<div class="col-md-8 col-sm-12 col-xs-12 float-right">
			<form id="myForm" action="">

			<table class="table text-right" id="individuals">
				<!-- <div class="Individuals-section hide"> -->
					<tr>
						<th colspan="2" class="text-center">بيانات السائق</th>
					</tr>
					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-info"></i></span>
							<input type="text" class="form-control" name="Bn_Aga_Oth_Ins_Driver_Id_no" id="Bn_Aga_Oth_Ins_Driver_Id_no" placeholder="رقم الهوية" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-calendar-plus-o"></i></span>
							<input type="text" class="form-control datepicker" name="Bn_Aga_Oth_Ins_Driver_Birthdate" id="Bn_Aga_Oth_Ins_Driver_Birthdate" placeholder="تاريخ الميلاد" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-certificate"></i></span>
							<input type="text" class="form-control" name="Bn_Aga_Oth_Ins_Driver_Work" id="Bn_Aga_Oth_Ins_Driver_Work" placeholder="المهنة" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-briefcase"></i></span>
							<input type="text" class="form-control" name="Bn_Aga_Oth_Ins_Driver_Job" id="Bn_Aga_Oth_Ins_Driver_Job" placeholder="الوظيفة" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-building-o"></i></span>
							<input type="text" class="form-control" name="Bn_Aga_Oth_Ins_Driver_Work_Place" id="Bn_Aga_Oth_Ins_Driver_Work_Place" placeholder="جهة العمل" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-calendar-plus-o"></i></span>
							<input type="text" class="form-control" name="Bn_Aga_Oth_Ins_Driver_National" id="Bn_Aga_Oth_Ins_Driver_National" placeholder="الجنسية" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>

						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-transgender"></i></span>
							<select name="Bn_Aga_Oth_Ins_Driver_Gender" id="Bn_Aga_Oth_Ins_Driver_Gender" class="form-control select-style" aria-describedby="basic-addon1">
								<option value="0" selected >الجنس</option>
								<option value="1">ذكر</option>
								<option value="2">أنثي</option>
							</select>
						</div></td>

						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-mars-stroke-h"></i></span>
							<select name="Bn_Aga_Oth_Ins_Driver_Social" id="Bn_Aga_Oth_Ins_Driver_Social" class="form-control select-style" aria-describedby="basic-addon1">
								<option value="0" selected >الحالة الإجتماعية</option>
								<option value="1">متزوج/ة</option>
								<option value="2">مطلق/ة</option>
							</select>
						</div></td>
						
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1" style="height: 34px;">هل توجد قيود صحية</span>
						
						</div></td>
						<td><div class="input-group" style="width: 100%">
							<!-- <span class="input-group-addon" id="basic-addon1">?</span> -->
							<select name="Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has" class="form-control select-style" id="Bn_Aga_Oth_Ins_Driver_Health_Constraint_View" aria-describedby="basic-addon1">
								<option value="0" selected >إختر الإجابة</option>
								<option value="1">نعم</option>
								<option value="2">لا</option>
							</select>
						</div></td>
					</tr>

				<!-- </div> -->
				</table>
				<table class="table text-right" id="for-helth" style="display:none;">
					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-medkit"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Driver_Health_Constraint" id="Bn_Aga_Oth_Ins_Driver_Health_Constraint" class="form-control" placeholder="القيد الصحي" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1" style="height: 34px; padding: 0;"><i class="fa fa-plus-square fa-2x"></i></span>
						</div></td>
					</tr>
				</table>



				<table class="table text-right" >
					<tr>
						<input type="hidden" name="confirm-action" value="Bn_Aga_Oth_Dri_confirm">
						<th class="text-center"><a href="W_Wep_Ins_Against_Others_Insured_Data.php"><button type="button" id="back" class="btn btn-warning">   <- السابق  </button></a></th>
						<!-- <th class="text-center"><a href="W_Wep_Ins_Against_Others_Vehicle_Data.php"><button type="button" id="next" class="btn btn-info">  التالي -> </button></a></th> -->
						<th class="text-center"><a href="#"><button type="button" id="next" class="btn btn-info">  التالي -> </button></a></th>
					</tr>
				</table>


		
	
				</form>
				</div>

				<div class="col-md-4 col-sm-hide col-xs-hide float-right">
					<div class="panel panel-warning">
						<div class="panel-heading"> إرشادات الموقع</div>
						<div class="panel-body">



						</div>
					</div>
				</div>

			</div> <!-- end of panel body  -->
		<!-- </div> -->
	</div>
 <!-- end of the form 	 -->
</div>
</div>


	
<?php include('Footer.php');?>






<!--   ------------------------------------------ 3)------------------------------------     -->

 <script>
	$("#Bn_Aga_Oth_Ins_Driver_Health_Constraint_View").change(function(){
		var val = $(this).val();

		if ( val === "1" ) {
		$("#for-helth").fadeIn(500);
		} else if ( val === "2" ) {
		$("#for-helth").hide();
		} else {
		$("#for-helth").hide();
		}

		return false;
	});

	$('.datepicker-genaral').datepicker();
	$('.datepicker-spacial').datepicker();
	$('.datepicker').datepicker();



	$("#next").click(function(){
		var check = 0;
			if($("#Bn_Aga_Oth_Ins_Driver_Id_no").val() == ''){
				$("#Bn_Aga_Oth_Ins_Driver_Id_no").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Birthdate").val() == ''){
				$("#Bn_Aga_Oth_Ins_Driver_Birthdate").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Work").val() == ''){
				$("#Bn_Aga_Oth_Ins_Driver_Work").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Job").val() == ''){
				$("#Bn_Aga_Oth_Ins_Driver_Job").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Work_Place").val() == ''){
				$("#Bn_Aga_Oth_Ins_Driver_Work_Place").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_National").val() == ''){
				$("#Bn_Aga_Oth_Ins_Driver_National").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Gender").val() == 0){
				$("#Bn_Aga_Oth_Ins_Driver_Gender").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Social").val() == 0){
				$("#Bn_Aga_Oth_Ins_Driver_Social").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Health_Constraint_View").val() == 0){
				$("#Bn_Aga_Oth_Ins_Driver_Health_Constraint_View").addClass("alert-danger");
				check = 1;
			}


			if($("#Bn_Aga_Oth_Ins_Driver_Health_Constraint_View").val() == 1){
				if($("#Bn_Aga_Oth_Ins_Driver_Health_Constraint").val() == ''){
					$("#Bn_Aga_Oth_Ins_Driver_Health_Constraint").addClass("alert-danger");
					check = 1;
				}
			}




		if(check == 0){
			$("#myForm").submit();
		}else{
			$.alert({
				title: 'تنبيه!',
				content: 'عفوا يجب ملئ جميع الحقول المطلوبة !!',
			});
		}
	});

	$(document).on("submit", "#myForm", function()
	{
		// event.preventDefault();  
			
		var formData = new FormData(this);

        $.ajax({
            type:'POST',
            url: 'application/confirm.php',
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
				console.log(data);
				if(data == true){

					location.href='W_Wep_Ins_Against_Others_Vehicle_Data.php';

					console.log(data);
				}else{
					console.log(data);
				}
                
            },
            error: function(data){
                console.log(data);
            }
		});
		
       

		return false;
	});
	 
	 
 </script>   
		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   
