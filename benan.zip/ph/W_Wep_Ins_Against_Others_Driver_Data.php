<?php include_once('Header.php') ?>
<?php
// if(@$_SESSION['status']!=1){
// 	echo "<script>location.href='index.php';</script>";
// }

// if(isset($_POST['Next'])){
	

//	individuals	
$Bn_Aga_Oth_Ins_Driver_Id_no = '';
$Bn_Aga_Oth_Ins_Driver_Birthdate = '';
$Bn_Aga_Oth_Ins_Driver_Work = '';
$Bn_Aga_Oth_Ins_Driver_Edication = '';
$Bn_Aga_Oth_Ins_Driver_Work_Place = '';
$Bn_Aga_Oth_Ins_Driver_National = '';
$Bn_Aga_Oth_Ins_Driver_Gender = '';
$Bn_Aga_Oth_Ins_Driver_Social = '';
$Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has = '';
$Bn_Aga_Oth_Ins_Driver_Health_Constraint = '';

if (isset($_COOKIE['Bn_Aga_Oth_Ins'])) {
	if (isset($_COOKIE['Bn_Aga_Oth_Ins_Driver'])) {
		$Bn_Aga_Oth_Ins_Driver = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Driver']);
		$Bn_Aga_Oth_Ins_Driver_Id_no = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Id_no;
		$Bn_Aga_Oth_Ins_Driver_Birthdate = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Birthdate;
		$Bn_Aga_Oth_Ins_Driver_Work = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Work;
		$Bn_Aga_Oth_Ins_Driver_Work_Place = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Work_Place;
		$Bn_Aga_Oth_Ins_Driver_Edication = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Edication;
		$Bn_Aga_Oth_Ins_Driver_National = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_National;
		$Bn_Aga_Oth_Ins_Driver_Gender = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Gender;
		$Bn_Aga_Oth_Ins_Driver_Social = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Social;
		$Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has;
		$Bn_Aga_Oth_Ins_Driver_Health_Constraint = $Bn_Aga_Oth_Ins_Driver->Bn_Aga_Oth_Ins_Driver_Health_Constraint;
	}
}else {
	echo "<script>location.href='W_Wep_Main_Menu.php';</script>";
}


?>
<!-- -->

<!--   -------------------------------------1) ----------------------------------------   -->



<!--   -----------------------------------------------------------------------------   -->


<div class="clearfix clearfix-space"></div>
<!--   ---------------------------------------------2)--------------------------------   -->

<div class="row" style="margin:0px auto;">
<div class="container">
 <!-- begin of the form 	 -->
 	<div class="panel panel-default">
	 	<div class="panel-heading"> <h4> تامين ضد الغير </h4> </div>

		<div class="panel-body">

			<!-- steps style -->
			<div class="row">
			<div class="container">

				<div class="against-other-steps">

					<a href="#"><img class="step" src="img/Step1.png"></a>
					<a href="#"><img class="step" src="img/Step2-a.png"></a>
					<a href="#"><img class="step" src="img/Step3.png"></a>
					<a href="#"><img class="step" src="img/Step4.png"></a>
					<a href="#"><img class="step" src="img/Step5.png"></a>
					<a href="#"><img class="step" src="img/Step6.png"></a>
					<a href="#"><img class="step" src="img/Step7.png"></a>
					<a href="#"><img class="step" src="img/Step8.png"></a>
				</div>
			</div>
			</div>


			<!-- end steps -->
			<div class="clearfix clearfix-space"></div>
			
			<div class="col-md-8 col-sm-12 col-xs-12 float-right">
			<form id="myForm" action="">

			<table class="table text-right" id="individuals">
				<!-- <div class="Individuals-section hide"> -->
					<tr>
						<th colspan="2" class="text-center">بيانات السائق</th>
					</tr>
					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-info"></i></span>
							<input type="text" class="form-control" name="Bn_Aga_Oth_Ins_Driver_Id_no" id="Bn_Aga_Oth_Ins_Driver_Id_no" value="<?php echo $Bn_Aga_Oth_Ins_Driver_Id_no;?>" placeholder="رقم الهوية" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-calendar-plus-o"></i></span>
							<input type="text" class="form-control datepicker" name="Bn_Aga_Oth_Ins_Driver_Birthdate" id="Bn_Aga_Oth_Ins_Driver_Birthdate" value="<?php echo $Bn_Aga_Oth_Ins_Driver_Birthdate;?>" placeholder="تاريخ الميلاد" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-certificate"></i></span>
							<input type="text" class="form-control" name="Bn_Aga_Oth_Ins_Driver_Work" id="Bn_Aga_Oth_Ins_Driver_Work" value="<?php echo $Bn_Aga_Oth_Ins_Driver_Work;?>" placeholder="المهنة" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-building-o"></i></span>
							<input type="text" class="form-control" name="Bn_Aga_Oth_Ins_Driver_Work_Place" id="Bn_Aga_Oth_Ins_Driver_Work_Place" value="<?php echo $Bn_Aga_Oth_Ins_Driver_Work_Place;?>" placeholder="جهة العمل" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
					<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-pencil-square-o"></i></span>
							<select name="Bn_Aga_Oth_Ins_Driver_Edication" id="Bn_Aga_Oth_Ins_Driver_Edication" class="form-control select-style" aria-describedby="basic-addon1">
								<option value="0" <?php if($Bn_Aga_Oth_Ins_Driver_Edication == '') { echo "selected" ; } ?> >المؤهل التعليمي</option>
								<option value="1" <?php if($Bn_Aga_Oth_Ins_Driver_Edication == '1') { echo "selected" ; } ?>>دكتورا</option>
								<option value="2" <?php if($Bn_Aga_Oth_Ins_Driver_Edication == '2') { echo "selected" ; } ?>>ماجستير</option>
								<option value="3" <?php if($Bn_Aga_Oth_Ins_Driver_Edication == '3') { echo "selected" ; } ?>>دبلوم عالي</option>
								<option value="4" <?php if($Bn_Aga_Oth_Ins_Driver_Edication == '4') { echo "selected" ; } ?>>بكلاريوس</option>
								<option value="5" <?php if($Bn_Aga_Oth_Ins_Driver_Edication == '5') { echo "selected" ; } ?>>دبلوم تقني</option>
							</select>
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-globe"></i></span>
							<input type="text" class="form-control" name="Bn_Aga_Oth_Ins_Driver_National" id="Bn_Aga_Oth_Ins_Driver_National" value="<?php echo $Bn_Aga_Oth_Ins_Driver_National;?>" placeholder="الجنسية" aria-describedby="basic-addon1">
						</div></td>
					</tr>

					<tr>
						<td>
							<div class="input-group" style="width: 100%;">
							<span class="input-group-addon">
								<label class="radio-inline">&nbsp;&nbsp;  الجنس  </label> &nbsp; &nbsp;
								<label class="radio-inline"><input type="radio" class="Bn_Aga_Oth_Ins_Driver_Gender" name="Bn_Aga_Oth_Ins_Driver_Gender" <?php if($Bn_Aga_Oth_Ins_Driver_Gender == '1') { echo "checked" ; } ?> value="1">&nbsp;&nbsp;  :ذكر  </label> &nbsp; &nbsp;
								<label class="radio-inline"><input type="radio" class="Bn_Aga_Oth_Ins_Driver_Gender" name="Bn_Aga_Oth_Ins_Driver_Gender" <?php if($Bn_Aga_Oth_Ins_Driver_Gender == '2') { echo "checked" ; } ?> value="2">&nbsp;&nbsp;  :أنثي  </label>
							</span>
							</div>
						</td>
						<td></td>

					</tr>
					<tr>

						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-mars-stroke-h"></i></span>
							<select name="Bn_Aga_Oth_Ins_Driver_Social" id="Bn_Aga_Oth_Ins_Driver_Social" class="form-control select-style" aria-describedby="basic-addon1">
								<option value="0" <?php if($Bn_Aga_Oth_Ins_Driver_Social == '') { echo "selected" ; } ?>>الحالة الإجتماعية</option>
								<option value="1" <?php if($Bn_Aga_Oth_Ins_Driver_Social == '1') { echo "selected" ; } ?>>متزوج/ة</option>
								<option value="2" <?php if($Bn_Aga_Oth_Ins_Driver_Social == '2') { echo "selected" ; } ?>>مطلق/ة</option>
							</select>
						</div></td>
						<td></td>
						
					</tr>

					<tr>
						<td style="width: 50%;" ><div class="input-group">
							<span class="input-group-addon" id="basic-addon1" style="height: 34px;">هل توجد قيود صحية</span>
						
						</div></td>
						<td><div class="input-group" style="width: 100%">
							<!-- <span class="input-group-addon" id="basic-addon1">?</span> -->
							<select name="Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has" class="form-control select-style" id="Bn_Aga_Oth_Ins_Driver_Health_Constraint_View" aria-describedby="basic-addon1">
								<option value="0" <?php if($Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has == '') { echo "selected" ; } ?>>إختر الإجابة</option>
								<option value="1" <?php if($Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has == '1') { echo "selected" ; } ?>>نعم</option>
								<option value="2" <?php if($Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has == '2') { echo "selected" ; } ?>>لا</option>
							</select>
						</div></td>
					</tr>

				<!-- </div> -->
				</table>
				<table class="table text-right" id="for-helth" <?php if($Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has == '1') { echo 'style="display:table;"' ; }else{ echo 'style="display:none;"'; } ?>>
					<tr>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><i class="fa fa-medkit"></i></span>
							<input type="text" name="Bn_Aga_Oth_Ins_Driver_Health_Constraint" id="Bn_Aga_Oth_Ins_Driver_Health_Constraint" value="<?php echo $Bn_Aga_Oth_Ins_Driver_Health_Constraint;?>" class="form-control" placeholder="القيد الصحي" aria-describedby="basic-addon1">
						</div></td>
						<td><div class="input-group">
							<span class="input-group-addon" id="basic-addon1" style="height: 34px; padding: 0;"><i class="fa fa-plus-square fa-2x"></i></span>
						</div></td>
					</tr>
				</table>



				<table class="table text-right" >
					<tr>
						<input type="hidden" name="confirm-action" value="Bn_Aga_Oth_Dri_confirm">
						<th class="text-center"><a href="W_Wep_Ins_Against_Others_Insured_Data.php"><button type="button" id="back" class="btn btn-warning">   <- السابق  </button></a></th>
						<!-- <th class="text-center"><a href="W_Wep_Ins_Against_Others_Vehicle_Data.php"><button type="button" id="next" class="btn btn-info">  التالي -> </button></a></th> -->
						<th class="text-center"><a href="#"><button type="button" id="next" class="btn btn-info">  التالي -> </button></a></th>
					</tr>
				</table>


		
	
				</form>
				</div>

				<div class="col-md-4 col-sm-hide col-xs-hide float-right">
					<div class="panel panel-warning">
						<div class="panel-heading"> إرشادات الموقع</div>
						<div class="panel-body">



						</div>
					</div>
				</div>

			</div> <!-- end of panel body  -->
		<!-- </div> -->
	</div>
 <!-- end of the form 	 -->
</div>
</div>


	
<?php include('Footer.php');?>






<!--   ------------------------------------------ 3)------------------------------------     -->

 <script>
	$("#Bn_Aga_Oth_Ins_Driver_Health_Constraint_View").change(function(){
		var val = $(this).val();

		if ( val === "1" ) {
		$("#for-helth").fadeIn(500);
		} else if ( val === "2" ) {
		$("#for-helth").hide();
		} else {
		$("#for-helth").hide();
		}

		return false;
	});

	$('.datepicker-genaral').datepicker();
	$('.datepicker-spacial').datepicker();
	$('.datepicker').datepicker();



	$("#next").click(function(){
		var check = 0;
			if($("#Bn_Aga_Oth_Ins_Driver_Id_no").val() == ''){
				$("#Bn_Aga_Oth_Ins_Driver_Id_no").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Birthdate").val() == ''){
				$("#Bn_Aga_Oth_Ins_Driver_Birthdate").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Work").val() == ''){
				$("#Bn_Aga_Oth_Ins_Driver_Work").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Edication").val() == 0){
				$("#Bn_Aga_Oth_Ins_Driver_Edication").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Work_Place").val() == ''){
				$("#Bn_Aga_Oth_Ins_Driver_Work_Place").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_National").val() == ''){
				$("#Bn_Aga_Oth_Ins_Driver_National").addClass("alert-danger");
				check = 1;
			}

			if(!$('.Bn_Aga_Oth_Ins_Driver_Gender').is(':checked'))
			{
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Social").val() == 0){
				$("#Bn_Aga_Oth_Ins_Driver_Social").addClass("alert-danger");
				check = 1;
			}

			if($("#Bn_Aga_Oth_Ins_Driver_Health_Constraint_View").val() == 0){
				$("#Bn_Aga_Oth_Ins_Driver_Health_Constraint_View").addClass("alert-danger");
				check = 1;
			}


			if($("#Bn_Aga_Oth_Ins_Driver_Health_Constraint_View").val() == 1){
				if($("#Bn_Aga_Oth_Ins_Driver_Health_Constraint").val() == ''){
					$("#Bn_Aga_Oth_Ins_Driver_Health_Constraint").addClass("alert-danger");
					check = 1;
				}
			}




		if(check == 0){
			$("#myForm").submit();
		}else{
			$.alert({
				title: 'تنبيه!',
				content: 'عفوا يجب ملئ جميع الحقول المطلوبة !!',
			});
		}
	});

	$(document).on("submit", "#myForm", function()
	{
		$('.loading-overlay').show();
		$('.view-loading-overlay').loading({ circles: 3,overlay: true });
			
		var formData = new FormData(this);

        $.ajax({
            type:'POST',
            url: 'application/confirm.php',
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
				console.log(data);
				setTimeout(() => {
					$('.loading-overlay').hide();
					if(data == true){

						location.href='W_Wep_Ins_Against_Others_Vehicle_Data.php';

						console.log(data);
					}else{
						$.alert({
							title: 'تنبيه!',
							content: 'فشلت العملية حاول مرة أخري !!',
						});
					}
                }, 500);
            },
            error: function(data){
                console.log(data);
            }
		});
		
       

		return false;
	});
	 
	 
 </script>   
		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   
<script src="js/moment.js"></script>
<script src="js/moment-hijri.js"></script>


<script>
    // moment.locale('ar-SA');// 2- Set the global locale to `ar-SA`
    // moment().format('iYYYY/iM/iD');
	// var y = m.format('iYYYY/iM/iD');
	$("#Bn_Aga_Oth_Ins_Driver_Birthdate").change(function(){

		var dateToHijri = $(this).val();
		var action = "dateToHijri";

		$.ajax({
            type:'POST',
            url: 'application/confirm.php',
            data:{action , dateToHijri},
            // cache:false,
            // contentType: false,
            // processData: false,
            success:function(data){
				console.log(data);
				$("#Bn_Aga_Oth_Ins_Driver_Birthdate").val(data);
			},
            error: function(data){
                console.log(data);
            }
		});

		
		
	})

	
	//   
      //١٤٣٧/٨/١٧هـ الموافق ٢٠١٦/٥/٢٤م
</script>