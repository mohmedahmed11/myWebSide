<?php



$host="loalhost";
$User="root";
$password="";
$db="cl60-benan";


mysqli_connect($host,$User,$password);

mysqli_select_db($db);

error_reporting(0); 


?>