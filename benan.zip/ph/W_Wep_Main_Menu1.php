<?php
session_start();

if(@$_SESSION['status']!=1){
	#echo "<script>location.href='index.php';</script>";
}

?>
<!-- -->


<!DOCTYPE html >
<html lang="ar" class="no-js" dir="rtl">
    <head id="ctl00_Head1"><meta charset="UTF-8" /><meta http-equiv="X-UA-Compatible" content="IE=10;Chrome=1;FF=3;OtherUA=4" /><meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" /><meta name="GENERATOR" content="Microsoft SharePoint" /><meta http-equiv="Content-type" content="text/html; charset=utf-8" /><meta http-equiv="Expires" content="0" /><title>
	شركة غيوم الودق لتقنية المعلومات
</title><link rel="stylesheet" href="css/normalize.css" /><!--[if IE 9]>
<link id="CssIE9" rel="stylesheet" type="text/css" href="/Style%20Library/sec/CSS/ng/css/IE9.css"/>
<![endif]-->
<link rel="stylesheet" href="css/font-awesome.min.css" />

<link id="CssRegistration1" rel="stylesheet" type="text/css" href="css/corev15.css?rev=oPMYfaqFDshrXtF%2Bx2UjjA%3D%3D"/>
<link id="CssRegistration2" rel="stylesheet" type="text/css" href="css/foundation.min.css"/>
<link id="CssRegistration4" rel="stylesheet" type="text/css" href="css/foundation.SPResets.css"/>
<link id="CssRegistration5" rel="stylesheet" type="text/css" href="css/stylesAr.css"/>
<link id="CssRegistration7" rel="stylesheet" type="text/css" href="css/SearchBoxStyle.css"/>

            
            
            <link rel="canonical" href="" />
            
            
        <link rel="icon" href="img/Logo_ar.png" type="image/x-icon" />
      <script  type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
              <!--[if lt IE 9]>
		<script type="text/javascript" src="js/html5.js">//<![CDATA[//]]></script>
		<link rel="stylesheet" href="../../_catalogs/masterpage/sec/css/ie.css" type="text/css" media="screen" />
	    <![endif]-->
		<style type="text/css">
			div#s4-ribbonrow {
			display:none;
			}
			div#suiteBar{
			display:none;
			}
		</style>
	    </head>
    <body id="">


            <div id="ctl00_SPSecurityTrimmedControl1">
	<div id="TurnOnAccessibility" style="display: none" class="s4-notdlg noindex"><a id="linkTurnOnAcc" href="#" class="ms-accessible ms-acc-button" onclick="SetIsAccessibilityFeatureEnabled(true);UpdateAccessibilityUI();document.getElementById('linkTurnOffAcc').focus();return false;">تشغيل وضع قابل للوصول بشكل أفضل</a></div><div id="TurnOffAccessibility" style="display: none" class="s4-notdlg noindex"><a id="linkTurnOffAcc" href="#" class="ms-accessible ms-acc-button" onclick="SetIsAccessibilityFeatureEnabled(false);UpdateAccessibilityUI();document.getElementById('linkTurnOnAcc').focus();return false;">إيقاف تشغيل الوضع القابل للوصول بشكل أفضل</a></div>
</div>
            <div id="ms-designer-ribbon">
                <div>
	
	<div id="s4-ribbonrow" style="visibility:hidden;display:none"></div>

</div>



            </div>
              
             <span id="ctl00_SPSecurityTrimmedControl2"></span>

         <div id="fadeMenu">
                <div id="secmain" class="body-Arabic">

                    <!-- Header -->
                    <?php include('Header.php') ?>
                    <!-- End Header -->

                    <!-- Main Image Slider -->
                    
<style type="text/css">
.menu-navigation-container, .breadcrumb-container{
	display:none !important;
}
.ms-webpartzone-cell{
	margin-bottom:auto;
}
#sidebar {
	width:50%;
	float:right;
	border:0!important;
	position:absolute;
	height:100%;
}
.slidebody{
right:50%;
position:relative;s
}
.quicklinksContainer div.blockhome.isOpen { transform: translate3d(260px, 0, 0); }
.hideDiv{
	display:none;
}
.imgWidth100 img {
	width:100%;
}
</style>








<link href="css/NewStylesAR.css" type="text/css" rel="stylesheet"/>

<div id="msidebar">

<!--   -------------------------------------1) ----------------------------------------   -->



<!--   -----------------------------------------------------------------------------   -->


<!--   ---------------------------------------------2)--------------------------------   -->

<center>
	<div class="col">
			<?php include('rightCol.html'); ?>

<div class="middleCol box">
				
				             <div class="columns large-4 md-6 sm-12 ">
	                		<div class="ms-webpart-zone ms-fullWidth">
	<div id="MSOZoneCell_WebPartctl00_SPWebPartManager1_g_5ee5aa55_f3e7_4874_94bb_01bbda429a3a" class="s4-wpcell-plain ms-webpartzone-cell ms-webpart-cell-vertical ms-fullWidth ">
		<div class="ms-webpart-chrome ms-webpart-chrome-vertical ms-webpart-chrome-fullWidth ">
			<div WebPartID="5ee5aa55-f3e7-4874-94bb-01bbda429a3a" HasPers="false" id="WebPartctl00_SPWebPartManager1_g_5ee5aa55_f3e7_4874_94bb_01bbda429a3a" width="100%" class="ms-WPBody " allowDelete="false" allowExport="false" style="" ><div id="ctl00_SPWebPartManager1_g_5ee5aa55_f3e7_4874_94bb_01bbda429a3a">
				<DIV class="ms-rte-embedcode ms-rte-embedwp"><a href="W_Wep_Ins_Against_Others_Insured_Data.php"><img src="img/InvestorRelations_AR.png" /></a></DIV>
			</div><div class="ms-clear"></div></div>
		</div>
	</div>
</div>
						</div>
						<div class="columns large-4 md-6 sm-12 ">
	                		<div class="ms-webpart-zone ms-fullWidth">
	<div id="MSOZoneCell_WebPartctl00_SPWebPartManager1_g_014317bc_1ee4_4657_9cbe_aa52132c5846" class="s4-wpcell-plain ms-webpartzone-cell ms-webpart-cell-vertical ms-fullWidth ">
		<div class="ms-webpart-chrome ms-webpart-chrome-vertical ms-webpart-chrome-fullWidth ">
			<div WebPartID="014317bc-1ee4-4657-9cbe-aa52132c5846" HasPers="false" id="WebPartctl00_SPWebPartManager1_g_014317bc_1ee4_4657_9cbe_aa52132c5846" width="100%" class="ms-WPBody " allowDelete="false" allowExport="false" style="" ><div id="ctl00_SPWebPartManager1_g_014317bc_1ee4_4657_9cbe_aa52132c5846">
				<DIV class="ms-rte-embedcode ms-rte-embedwp"><a href="#"><img  src="img/Business_AR.png"/></a></DIV>
			</div><div class="ms-clear"></div></div>
		</div>
	</div>
</div>
	                    </div>
	                    <div class="columns large-4 md-6 sm-12 ">
	                		<div class="ms-webpart-zone ms-fullWidth">
	<div id="MSOZoneCell_WebPartctl00_SPWebPartManager1_g_e124350a_f5a3_4020_9caf_3cda11b4d4a5" class="s4-wpcell-plain ms-webpartzone-cell ms-webpart-cell-vertical ms-fullWidth ">
		<div class="ms-webpart-chrome ms-webpart-chrome-vertical ms-webpart-chrome-fullWidth ">
			<div WebPartID="e124350a-f5a3-4020-9caf-3cda11b4d4a5" HasPers="false" id="WebPartctl00_SPWebPartManager1_g_e124350a_f5a3_4020_9caf_3cda11b4d4a5" width="100%" class="ms-WPBody " allowDelete="false" allowExport="false" style="" ><div id="ctl00_SPWebPartManager1_g_e124350a_f5a3_4020_9caf_3cda11b4d4a5">
				<DIV class="ms-rte-embedcode ms-rte-embedwp"><a href="W_Wep_Ins_Medical_Traveler_Insured_Data.php"><img src="img/InformationAboutCompany_AR.png"/></a>​​​​​</DIV>
			</div><div class="ms-clear"></div></div>
		</div>
	</div>
</div>
	                    </div>

	                   
						<div class="columns large-4 md-6 sm-12 ">
	                   		<div class="ms-webpart-zone ms-fullWidth">
	<div id="MSOZoneCell_WebPartctl00_SPWebPartManager1_g_f5e586be_3a9e_4654_a71a_fb29ebb53b93" class="s4-wpcell-plain ms-webpartzone-cell ms-webpart-cell-vertical ms-fullWidth ">
		<div class="ms-webpart-chrome ms-webpart-chrome-vertical ms-webpart-chrome-fullWidth ">
			<div WebPartID="f5e586be-3a9e-4654-a71a-fb29ebb53b93" HasPers="false" id="WebPartctl00_SPWebPartManager1_g_f5e586be_3a9e_4654_a71a_fb29ebb53b93" width="100%" class="ms-WPBody " allowDelete="false" allowExport="false" style="" ><div id="ctl00_SPWebPartManager1_g_f5e586be_3a9e_4654_a71a_fb29ebb53b93">
				<DIV class="ms-rte-embedcode ms-rte-embedwp"><a href="W_Wep_Summary_News.php"><img  src="img/OurNews.png"/></a></DIV>
			</div><div class="ms-clear"></div></div>
		</div>
	</div>
</div>
	                    </div>
						<div class="columns large-4 md-6 sm-12 ">
	                   		<div class="ms-webpart-zone ms-fullWidth">
	<div id="MSOZoneCell_WebPartctl00_SPWebPartManager1_g_f5e586be_3a9e_4654_a71a_fb29ebb53b93" class="s4-wpcell-plain ms-webpartzone-cell ms-webpart-cell-vertical ms-fullWidth ">
		<div class="ms-webpart-chrome ms-webpart-chrome-vertical ms-webpart-chrome-fullWidth ">
			<div WebPartID="f5e586be-3a9e-4654-a71a-fb29ebb53b93" HasPers="false" id="WebPartctl00_SPWebPartManager1_g_f5e586be_3a9e_4654_a71a_fb29ebb53b93" width="100%" class="ms-WPBody " allowDelete="false" allowExport="false" style="" ><div id="ctl00_SPWebPartManager1_g_f5e586be_3a9e_4654_a71a_fb29ebb53b93">
				<DIV class="ms-rte-embedcode ms-rte-embedwp"><a href="W_Wep_Summary_Previous_Requests.php"><img  src="img/PreviousRequests.png"/></a></DIV>
			</div><div class="ms-clear"></div></div>
		</div>
	</div>
</div>
	                    </div>
						<div class="columns large-4 md-6 sm-12 ">
	                   		<div class="ms-webpart-zone ms-fullWidth">
	<div id="MSOZoneCell_WebPartctl00_SPWebPartManager1_g_f5e586be_3a9e_4654_a71a_fb29ebb53b93" class="s4-wpcell-plain ms-webpartzone-cell ms-webpart-cell-vertical ms-fullWidth ">
		<div class="ms-webpart-chrome ms-webpart-chrome-vertical ms-webpart-chrome-fullWidth ">
			<div WebPartID="f5e586be-3a9e-4654-a71a-fb29ebb53b93" HasPers="false" id="WebPartctl00_SPWebPartManager1_g_f5e586be_3a9e_4654_a71a_fb29ebb53b93" width="100%" class="ms-WPBody " allowDelete="false" allowExport="false" style="" ><div id="ctl00_SPWebPartManager1_g_f5e586be_3a9e_4654_a71a_fb29ebb53b93">
				<DIV class="ms-rte-embedcode ms-rte-embedwp"><a href="W_Wep_Video_definition.php"><img  src="img/VirtualTour.png"/></a></DIV>
			</div><div class="ms-clear"></div></div>
		</div>
	</div>
</div>
	                    </div>
					
	</div>
	
<?php include('leftCol.html');?>



</div>
</center>

				            
				
			




<!--   ------------------------------------------ 3)------------------------------------     -->


		            
<!-- ------------------------------------- 4  ---------------------------------------- -->	   
		    	   

                
             
	



<!--   ------------------------------------------------------------------------------     -->

<div class="mobile-footer-toggle">
	<div class="row apps text-center">

	</div>

</div>

                    <!-- End Image Slider -->

                    <div class="wrapper">
                        <!-- Content Container -->
                      <?php include('Footer.php');?>

                        <!-- Footer -->
                       
                        <!-- End Footer -->

         


                        <!-- Developer Dashboard -->
                        
                    </div>
                
</div></div>
            <div id="DeltaFormDigest">

        <span id="DeltaPlaceHolderUtilityContent">
            
        </span>
  
 

        
       </body>
           <!-- End Hide Unused Placeholders -->
</html><!-- تم التقديم باستخدام ملف تعريف ذاكرة تخزين مؤقتة:Public Internet (Purely Anonymous) في: 2018-07-20T11:03:17 -->