<?php
ob_start();
session_start();

include_once("medoo.php");

$_SESSION['_token'] = array();

if($_SERVER['REQUEST_METHOD'] === 'POST'){
//echo $_POST['_token_session'];
    // if(!isset($_POST['_token_session']) || ($_POST['_token_session'] !== $_SESSION['_token_check'])){
    //     die("invaled csrf request".$_SESSION['_token_check']);
    // }

    function e($string){
        return  htmlentities(htmlspecialchars($string, ENT_QUOTES, 'UTF-8'));
    }

    function array_from_post($array,$item = NULL){
        $echo = array();
        $sup = array();
        if($item == NULL){
            foreach($array as $value)
            {
                $echo[$value] = e($_POST[$value]);
            }
        }else{
            for($x=0; $x<$item; $x++){
                foreach($array as $value)
                {
                    $string = $_POST[$value][$x];
                    $echo[$x][$value] = e($string);
                }
            }
        }
        return $echo;
    }

    if (isset($_POST['confirm-action']) && $_POST['confirm-action'] == 'Bn_Aga_Oth_Ins_confirm') {
        # code...
        // setcookie("age", "36", time()+3600, "/", "",  0);
        
        $Bn_Sup_Sector_Code = $_POST['Bn_Sup_Sector_Code'];
        $Bn_Aga_Oth_Ins_Start_Date = $_POST['Bn_Aga_Oth_Ins_Start_Date'];

        // setcookie("Bn_Sup_Sector_Code", $Bn_Sup_Sector_Code, time()+(3600 * 24), "/", "",  0);
        // setcookie("Bn_Aga_Oth_Ins_Start_Date", $Bn_Aga_Oth_Ins_Start_Date, time()+(3600 * 24), "/", "",  0);
    
        $array = array('Bn_Sup_Sector_Code','Bn_Aga_Oth_Ins_Start_Date');
        $result = array_from_post($array);

        $json_str = json_encode($result); 
        setcookie("Bn_Aga_Oth_Ins", $json_str, time()+(3600 * 24),"/",false);

        // $data = "lkjfgfgfgfgfgsk";
        if($Bn_Sup_Sector_Code == 'genaral'){
            $arrayData = array(
                'Bn_Aga_Oth_Ins_Gov_No',
                'Bn_Aga_Oth_Ins_Gov_Id_No',
                'Bn_Aga_Oth_Ins_Gov_Id_Name',
                'Bn_Aga_Oth_Ins_Gov_Id_Date',
                'Bn_Aga_Oth_Ins_Gov_Driver');

                $tmpFilePath = $_FILES['Bn_Aga_Oth_Ins_Gov_Id_Image']['tmp_name'];

                // $Bn_Aga_Oth_Ins_Gov_Id_Image = $_FILES['Bn_Aga_Oth_Ins_Gov_Id_Image']['name'];

                $result = array_from_post($arrayData);

                //Make sure we have a file path
                if ($tmpFilePath != ""){
                    //Setup our new file path
                    $ext = explode("/",$_FILES['Bn_Aga_Oth_Ins_Gov_Id_Image']['type']);
                    $newFileName =  date("dmYHis_").'Gov_Id_Image.'.$ext[1];
                    $newFilePath = "../tmp_img/" . $newFileName;

                    //Upload the file into the temp dir
                    if(move_uploaded_file($tmpFilePath, $newFilePath)) {
                        
                        $result['Bn_Aga_Oth_Ins_Gov_Id_Image'] = $newFileName;
                        $json_str = json_encode($result); 
                        setcookie("Bn_Aga_Oth_Ins_Gov", $json_str, time()+(3600 * 24),"/",false);
                        $data = true;
                        
                    }else{
                        $data = false;
                    }
                }else{
                    $data = false;
                }

        }elseif($Bn_Sup_Sector_Code == 'spacial'){
            $arrayData = array(
                'Bn_Aga_Oth_Ins_Spe_No',
                'Bn_Aga_Oth_Ins_Spe_Id_No',
                'Bn_Aga_Oth_Ins_Spe_Id_Name',
                'Bn_Aga_Oth_Ins_Spe_Id_Date',
                'Bn_Aga_Oth_Ins_Spe_Driver');

                // $tmpFilePath = '';
                $tmpFilePath = $_FILES['Bn_Aga_Oth_Ins_Spe_Id_Image']['tmp_name'];

                // $Bn_Aga_Oth_Ins_Spe_Id_Image = $_FILES['Bn_Aga_Oth_Ins_Spe_Id_Image']['name'];

                $result = array_from_post($arrayData);

                //Make sure we have a file path
                if ($tmpFilePath != ""){
                    //Setup our new file path
                    $ext = explode("/",$_FILES['Bn_Aga_Oth_Ins_Spe_Id_Image']['type']);
                    $newFileName =  date("dmYHis_").'Spe_Id_Image.'.$ext[1];
                    $newFilePath = "../tmp_img/" . $newFileName;

                    //Upload the file into the temp dir
                    if(move_uploaded_file($tmpFilePath, $newFilePath)) {
                        
                        $result['Bn_Aga_Oth_Ins_Spe_Id_Image'] = $newFileName;

                        $json_str = json_encode($result); 
                        setcookie("Bn_Aga_Oth_Ins_Spe", $json_str, time()+(3600 * 24),"/",false);
                        $data = true;
                        
                    }else{
                        $data = false;
                    }
                }else{
                    $data = false;
                }

        }elseif($Bn_Sup_Sector_Code == 'individuals'){
            $arrayData = array(
                'Bn_Aga_Oth_Ins_Ind_no',
                'Bn_Aga_Oth_Ins_Ind_Birth_Date',
                'Bn_Aga_Oth_Ins_Ind_Work',
                'Bn_Aga_Oth_Ins_Ind_Job',
                'Bn_Aga_Oth_Ins_Ind_Work_Place',
                'Bn_Aga_Oth_Ins_Ind_National',
                'Bn_Aga_Oth_Ins_Ind_Gender',
                'Bn_Aga_Oth_Ins_Ind_Social',
                'Bn_Aga_Oth_Ins_Ind_Driver');

                $result = array_from_post($arrayData);

                $json_str = json_encode($result); 
                setcookie("Bn_Aga_Oth_Ins_Ind", $json_str, time()+(3600 * 24),"/",false);
                $data = true;
        }else{
            $data = false;
        }

        header('Content-Type: application/json');
        echo json_encode($data);
    }

    if (isset($_POST['confirm-action']) && $_POST['confirm-action'] == 'Bn_Aga_Oth_Dri_confirm') {
        # code...
        // setcookie("age", "36", time()+3600, "/", "",  0);
        $arrayData = array(
            'Bn_Aga_Oth_Ins_Driver_Id_no',
            'Bn_Aga_Oth_Ins_Driver_Birthdate',
            'Bn_Aga_Oth_Ins_Driver_Work',
            'Bn_Aga_Oth_Ins_Driver_Job',
            'Bn_Aga_Oth_Ins_Driver_Work_Place',
            'Bn_Aga_Oth_Ins_Driver_National',
            'Bn_Aga_Oth_Ins_Driver_Gender',
            'Bn_Aga_Oth_Ins_Driver_Social',
            'Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has',
            'Bn_Aga_Oth_Ins_Driver_Health_Constraint');

            $result = array_from_post($arrayData);

            $json_str = json_encode($result); 
            setcookie("Bn_Aga_Oth_Ins_Driver", $json_str, time()+(3600 * 24),"/",false);
            $data = true;

        header('Content-Type: application/json');
        echo json_encode($data);
    }

    if (isset($_POST['confirm-action']) && $_POST['confirm-action'] == 'Bn_Aga_Oth_Veh_confirm') {
        # code...
        // setcookie("age", "36", time()+3600, "/", "",  0);
        $arrayData = array(
            'Bn_Sup_Ins_Vehicle_Purpose',
            'Bn_Sup_Ins_Vehicle_HSCode',
            'Bn_Sup_Ins_Vehicle_Use',
            'Bn_Sup_Ins_Vehicle_Area_Code',
            'Bn_Sup_Ins_Vehicle_City_Code',
            'Bn_Sup_Ins_Vehicle_Manufacturing_Year');

            $result = array_from_post($arrayData);

            $json_str = json_encode($result); 
            setcookie("Bn_Aga_Oth_Ins_Vehicle", $json_str, time()+(3600 * 24),"/",false);
            $data = true;
        
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    if (isset($_POST['confirm-action']) && $_POST['confirm-action'] == 'Bn_Aga_Oth_Price_confirm') {
        # code...
        // setcookie("age", "36", time()+3600, "/", "",  0);
           
        $arrayData = array(
            'Bn_Aga_Oth_Ins_Code');

            $result = array_from_post($arrayData);

            $json_str = json_encode($result); 
            setcookie("Bn_Aga_Oth_Ins_Price", $json_str, time()+(3600 * 24),"/",false);
            $data = true;
        
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    if (isset($_POST['confirm-action']) && $_POST['confirm-action'] == 'Bn_Aga_Oth_Payment_confirm') {
        # code...
        // setcookie("age", "36", time()+3600, "/", "",  0); 
        $arrayData = array(
            'Bn_Aga_Oth_Ins_Phone_No',
            'Bn_Aga_Oth_Ins_Acount_No',
            'Bn_Aga_Oth_Ins_Acount_Email');

            $result = array_from_post($arrayData);

            if (isset($_POST['Bn_Aga_Oth_Ins_Deliver'])) {
                # code...
                $result['Bn_Aga_Oth_Ins_Deliver'] = $_POST['Bn_Aga_Oth_Ins_Deliver'];
            }

            $json_str = json_encode($result); 
            setcookie("Bn_Aga_Oth_Ins_Payment", $json_str, time()+(3600 * 24),"/",false);
            $data = true;
        
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    if (isset($_POST['confirm-action']) && $_POST['confirm-action'] == 'Bn_Aga_Oth_Finish_confirm') {
        # code...
        // setcookie("age", "36", time()+3600, "/", "",  0);

        $arrayData = array('Bn_Aga_Oth_Ins_confirm');

        $result = array_from_post($arrayData);

        $Bn_Aga_Oth_Ins_confirm = $result['Bn_Aga_Oth_Ins_confirm'];

        if($Bn_Aga_Oth_Ins_confirm == '277162'){
        //	public data
            $Bn_Aga_Oth_Ins = json_decode($_COOKIE['Bn_Aga_Oth_Ins']);
            $Bn_Sup_Sector_Code = '';
            $Bn_Aga_Oth_Ins_Start_Date = '';

            $Bn_Aga_Oth_Ins_Gov_Driver = '';
            $Bn_Aga_Oth_Ins_Spe_Driver = '';
            $Bn_Aga_Oth_Ins_Ind_Driver = '';
            
            if($Bn_Sup_Sector_Code == 'genaral'){
            // 	genaral
                $Bn_Aga_Oth_Ins_Gov = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Gov']);
                $Bn_Aga_Oth_Ins_Gov_No = '';
                $Bn_Aga_Oth_Ins_Gov_Id_No = '';
                $Bn_Aga_Oth_Ins_Gov_Id_Name = '';
                $Bn_Aga_Oth_Ins_Gov_Id_Date = '';
                $Bn_Aga_Oth_Ins_Gov_Id_Image = '';
                $Bn_Aga_Oth_Ins_Gov_Driver = '';

            }else if($Bn_Sup_Sector_Code == 'spacial'){
            // 	spacial
                $Bn_Aga_Oth_Ins_Spe = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Spe']);
                $Bn_Aga_Oth_Ins_Spe_No = '';
                $Bn_Aga_Oth_Ins_Spe_Id_No = '';
                $Bn_Aga_Oth_Ins_Spe_Id_Name = '';
                $Bn_Aga_Oth_Ins_Spe_Id_Date = '';
                $Bn_Aga_Oth_Ins_Spe_Id_Image = '';
                $Bn_Aga_Oth_Ins_Spe_Driver = '';

            }else if($Bn_Sup_Sector_Code == 'individuals'){
            //	individuals	
                $Bn_Aga_Oth_Ins_Ind = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Ind']);
                $Bn_Aga_Oth_Ins_Ind_no = '';
                $Bn_Aga_Oth_Ins_Ind_Birth_Date = '';
                $Bn_Aga_Oth_Ins_Ind_Work = '';
                $Bn_Aga_Oth_Ins_Ind_Job = '';
                $Bn_Aga_Oth_Ins_Ind_Work_Place = '';
                $Bn_Aga_Oth_Ins_Ind_National = '';
                $Bn_Aga_Oth_Ins_Ind_Gender = '';
                $Bn_Aga_Oth_Ins_Ind_Social = '';
                $Bn_Aga_Oth_Ins_Ind_Driver = '';
            }

            $show_driver_data = 0;
				
            if($Bn_Sup_Sector_Code == 'individuals' ) { 
                if($Bn_Aga_Oth_Ins_Ind_Driver == 2) {
                    $show_driver_data = 1;
                }
            }else if ($Bn_Sup_Sector_Code == 'spacial') {
                if($Bn_Aga_Oth_Ins_Spe_Driver == 1) {
                    $show_driver_data = 1;
                }
            }else if ($Bn_Sup_Sector_Code == 'genaral') {
                if($Bn_Aga_Oth_Ins_Gov_Driver == 1) {
                    $show_driver_data = 1;
                }
            }
                
            if($show_driver_data == 1){	
            // 	driver data
                $Bn_Aga_Oth_Ins_Driver = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Driver']);
                $Bn_Aga_Oth_Ins_Driver_Id_no = '';
                $Bn_Aga_Oth_Ins_Driver_Birthdate = '';
                $Bn_Aga_Oth_Ins_Driver_Work = '';
                $Bn_Aga_Oth_Ins_Driver_Job = '';
                $Bn_Aga_Oth_Ins_Driver_Work_Place = '';
                $Bn_Aga_Oth_Ins_Driver_National = '';
                $Bn_Aga_Oth_Ins_Driver_Gender = '';
                $Bn_Aga_Oth_Ins_Driver_Social = '';
                $Bn_Aga_Oth_Ins_Driver_Health_Constraint_Has = '';
                $Bn_Aga_Oth_Ins_Driver_Health_Constraint = '';
            }

            if(isset($_COOKIE['Bn_Aga_Oth_Ins_Vehicle'])){
            // 	Vehicle data
                $Bn_Aga_Oth_Ins_Vehicle = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Vehicle']);
                $Bn_Sup_Ins_Vehicle_Purpose = '';
                $Bn_Sup_Ins_Vehicle_HSCode = '';
                $Bn_Sup_Ins_Vehicle_Use = '';
                $Bn_Sup_Ins_Vehicle_Area_Code = '';
                $Bn_Sup_Ins_Vehicle_City_Code = '';
                $Bn_Sup_Ins_Vehicle_Manufacturing_Year = '';
            }

            if(isset($_COOKIE['Bn_Aga_Oth_Ins_Price'])){
                $Bn_Aga_Oth_Ins_Price = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Price']);
                $Bn_Aga_Oth_Ins_Code = '';
            }

            if(isset($_COOKIE['Bn_Aga_Oth_Ins_Payment'])){
                $Bn_Aga_Oth_Ins_Payment = json_decode($_COOKIE['Bn_Aga_Oth_Ins_Payment']);
                $Bn_Aga_Oth_Ins_Phone_No = '';
                $Bn_Aga_Oth_Ins_Acount_No = '';
                $Bn_Aga_Oth_Ins_Acount_Email = '';
                $Bn_Aga_Oth_Ins_Deliver = '';
            }

            $Bn_Aga_Oth_Insert = "INSERT INTO `bn_against_others_insurance_data` VALUES()";

            // $obj->query($Bn_Aga_Oth_Insert);
            // $adminId = $obj->id();
        }

        $json_str = json_encode($result); 
        // setcookie("Bn_Aga_Oth_Ins_Payment", $json_str, time()+(3600 * 24),"/",false);
        $data = true;

        header('Content-Type: application/json');
        echo json_encode($data);
    }
}
