<?php
if(file_exists('../../vendor/autoload.php')  == true ){
    require '../../vendor/autoload.php';
}elseif(file_exists('../vendor/autoload.php')  == true ){
    require '../vendor/autoload.php';
}elseif(file_exists('vendor/autoload.php')  == true ){
    require 'vendor/autoload.php';
}
// Using Medoo namespace
use Medoo\Medoo;
 
// Initialize
$obj = new Medoo([
    'database_type' => 'mysql',
    'database_name' => 'cl60-benan',
    'server' => 'localhost',
    'username' => 'root',
    'password' => ''
]);
