<?php
ob_start();
session_start();
// include_once("Hijri_date.php");
include_once("application/var_dump.php");

?>

<!DOCTYPE html >
<html dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1.0">
  <title>بنان للتأمين</title>
  <link rel="icon" href="img/Logo_ar.png" type="image/x-icon" />
  <link rel="shortcut icon" href="favicon.ico">

  <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
  <link href="css/bootstrap.ar.css" rel="stylesheet" type="text/css" />
  <link href="css/bootstrap-theme.min.css" rel="stylesheet" type="text/css" />
  <link href="css/jquery-ui.css" rel="stylesheet" type="text/css" />
  <link href="css/jquery-confirm.min.css" rel="stylesheet" type="text/css" />
  <link href="css/jquery-loading.css" rel="stylesheet">


  <!-- <link href="css/checkboxStyle.css" rel="stylesheet" type="text/css" /> -->
  <!-- <link href="https://fonts.googleapis.com/css?family=Changa" rel="stylesheet"> -->
  <link href="https://fonts.googleapis.com/css?family=Mada|Cairo|Changa&amp;subset=arabic,latin-ext" rel="stylesheet">
  <link href="css/myStyle.css" rel="stylesheet" type="text/css" />
  <style>
    /* @import url('https://fonts.googleapis.com/css?family=Mada|Cairo|Changa&subset=arabic,latin-ext'); */
  </style>
</head>
  <body id="page1" onhashchange="if (typeof(_spBodyOnHashChange) != 'undefined') _spBodyOnHashChange();">
    <div class="page-header-controller">
    <div class="page-header">
    <nav class="container">
    <div class="row">

      <div class="col-md-2 col-sm-6 col-xs-6 float-right logobrand">
        <img src="img/Logo_ar.png"> 
      </div>
      
      <div class="col-md-3 ccol-sm-6 col-xs-6 float-right date">
    <p>
  
    <?php
        include("libs/Calndar.php");
        $dates = new DateTime("2012-07-05 16:43:21", new DateTimeZone('Europe/Paris')); 

        date_default_timezone_set('America/New_York'); 

        //echo date("Y-m-d h:iA", $date->format('U')); 

        $hijri_settings=array('langcode'=>'ar','defaultformat'=>'_j _M _Yهـ','umalqura'=> TRUE,
        'adj_data'=> array(1426 => 57250, 1429 => 57339,),
            'grdate_format' => 'j M Y',
  );  //settings of hijri date
        $cal_obj=new Calendar($hijri_settings);
            $miladi =  date("Y/m/d", $dates->format('U'));  
        list($Y, $M, $D) = explode('/', $miladi); // return integer variables to month,day, and an year from miladi date
        
        $nameOfMonth_Miladi = $cal_obj->Jul_Month_Arabic_Name($M); //  miladi month name

        
        $dt = new DateTime();
            $jd = unixtojd( $dt->getTimestamp()); //getting julian date 
            $hijriDate=$cal_obj->JDToHijri($jd);
        list($m, $d, $y) = explode('/', $hijriDate); // return integer variables to month,day, and an year from hijri
        $nameOfMonth_hij = $cal_obj->month_name($m); //  hijri month name
        $nameOfDay = date('D', strtotime($miladi)); //today english name
            $ar_day=$cal_obj->Day_Arabic_Name($nameOfDay); //today arabic name

        

    
            echo($ar_day." ".$d." ".$nameOfMonth_hij." ".$y."هـ");	
        echo("</br>");	
        echo("الموافق ".$D." ".$nameOfMonth_Miladi." ".$Y."م"); ?>
  </p>
  </div>
      
      <div class="col-md-3 col-sm-12 col-xs-12 float-left text-left">
        <div class="form-group">
        <a class="enlang" href="#"> عربي </a> <a class="enlang" href="#">| English&nbsp;</a> 
        </div>
        <div class="form-group">

          <a class="home-header" href="W_Wep_Main_Menu.php">
            <i class="fa fa-home fa-2x"></i>
          </a>
          <a class="home-header " href="#">
            <i class="fa fa-facebook-official fa-2x"></i>
          </a>
          <a class="home-header " href="#">
            <i class="fa fa-twitter-square fa-2x"></i>
          </a>
          <a class="home-header " href="#">
            <i class="fa fa-linkedin-square fa-2x"></i>
          </a>
        </div>

        <!-- <div class="input-group" >
          <label for="search-input"></label>
          <input type="text" class="form-control" placeholder="ابحث هنا ..." aria-label="Amount (to the nearest dollar)">
          <span class="input-group-btn">
            <button class="btn btn-default" type="button"><i class="fa fa-search fa-1x"></i></button>
          </span>
        </div> -->
      </div>
    </div>
    

  </nav>
  </div>
  </div>
        
         


<!--   -------------------------------------1) ----------------------------------------   -->

